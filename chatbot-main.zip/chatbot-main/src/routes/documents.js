const express = require('express');
const vectorDbService = require('../services/vectorDbService');

const router = express.Router();

/**
 * GET /api/documents
 * List all documents currently stored in the Vector DB.
 */
router.get('/', (req, res) => {
  try {
    const documents = vectorDbService.getAllDocuments();
    const stats = vectorDbService.getStats();
    res.json({
      success: true,
      count: documents.length,
      documents,
      stats
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/documents/:id/chunks
 * Fetch the raw text chunks of a document (for the document inspector).
 */
router.get('/:id/chunks', (req, res) => {
  try {
    const docId = req.params.id;
    const doc = vectorDbService.documents.get(docId);
    if (!doc) {
      return res.status(404).json({ success: false, error: 'Document not found' });
    }
    const chunks = vectorDbService.getDocumentChunks(docId);
    res.json({ success: true, docId, chunkCount: chunks.length, chunks });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * DELETE /api/documents/:id
 * Delete a specific document and its vector chunks (or 'all' to clear store).
 */
router.delete('/:id', (req, res) => {
  try {
    const docId = req.params.id;
    if (docId === 'all') {
      vectorDbService.clearAll();
      return res.json({ success: true, message: 'Cleared all documents and vector embeddings' });
    }

    const deleted = vectorDbService.deleteDocument(docId);
    if (!deleted) {
      return res.status(404).json({ success: false, error: 'Document not found' });
    }

    res.json({ success: true, message: `Deleted document ${docId}` });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
