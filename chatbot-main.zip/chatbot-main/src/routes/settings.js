const express = require('express');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const { OpenAI } = require('openai');
const config = require('../config');

const router = express.Router();

/**
 * POST /api/settings/verify-key
 * Test connection and validate a Gemini or OpenAI API key.
 */
router.post('/verify-key', async (req, res) => {
  try {
    const { apiKey, provider } = req.body;
    const activeProvider = (provider || config.llmProvider).toLowerCase();

    if (activeProvider === 'gemini') {
      const keyToUse = (apiKey || config.geminiApiKey || '').trim();
      if (!keyToUse) {
        return res.status(400).json({ valid: false, error: 'No Gemini API key provided to verify.' });
      }

      const genAI = new GoogleGenerativeAI(keyToUse);
      const model = genAI.getGenerativeModel({ model: config.geminiChatModel || 'gemini-flash-latest' });
      // Minimal generation to confirm the key works end-to-end
      await model.generateContent({ contents: [{ role: 'user', parts: [{ text: 'Reply with OK' }] }] });
      return res.json({
        valid: true,
        provider: 'gemini',
        message: 'Google Gemini API Key validated successfully!',
        model: config.geminiChatModel
      });
    }

    if (activeProvider === 'openai') {
      const keyToUse = (apiKey || config.openaiApiKey || '').trim();
      if (!keyToUse) {
        return res.status(400).json({ valid: false, error: 'No OpenAI API key provided to verify.' });
      }

      const client = new OpenAI({ apiKey: keyToUse });
      const models = await client.models.list();
      return res.json({
        valid: true,
        provider: 'openai',
        message: 'OpenAI API Key validated successfully!',
        availableModelsCount: models.data.length
      });
    }

    return res.status(400).json({ valid: false, error: `Unknown provider: ${activeProvider}` });
  } catch (err) {
    console.error('[Settings Verify Error]:', err.message);
    return res.status(400).json({
      valid: false,
      error: err.message || 'Failed to authenticate API Key'
    });
  }
});

module.exports = router;
