const express = require('express');
const vectorDbService = require('../services/vectorDbService');
const llmService = require('../services/llmService');
const config = require('../config');

const router = express.Router();

/**
 * GET /api/stats
 * Analytics, vector counts, provider info & health status.
 */
router.get('/', (req, res) => {
  try {
    const stats = vectorDbService.getStats();
    const providerInfo = llmService.getProviderInfo();

    res.json({
      success: true,
      appName: config.appName,
      version: config.version,
      builtBy: config.builtBy,
      stats: {
        ...stats,
        providerInfo,
        activeProvider: providerInfo.provider,
        defaultChunkSize: config.chunkSize,
        defaultChunkOverlap: config.chunkOverlap,
        defaultTopK: config.topK
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
