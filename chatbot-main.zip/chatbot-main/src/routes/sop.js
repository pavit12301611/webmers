const express = require('express');
const sopService = require('../services/sopService');

const router = express.Router();

/**
 * POST /api/sop
 * Stream a Standard Operating Procedure generated from the knowledge base.
 */
router.post('/', async (req, res) => {
  const controller = new AbortController();
  const abort = () => controller.abort();
  req.on('close', abort);
  res.on('close', abort);

  try {
    const { query, provider, chatModel, topK, embeddingModel } = req.body;
    const customApiKey = req.headers['x-api-key'] || req.headers['x-openai-api-key'] || req.headers['x-gemini-api-key'] || null;

    if (!query || !query.trim()) {
      res.status(400).json({ error: 'Query string is required' });
      return;
    }

    await sopService.streamSop({
      query,
      res,
      customApiKey,
      provider,
      topK: topK ? parseInt(topK, 10) : undefined,
      chatModel: chatModel || null,
      embeddingModel: embeddingModel || null,
      signal: controller.signal
    });
  } catch (err) {
    if (controller.signal.aborted) return;
    console.error('[SOP Route Error]:', err.message);
    if (!res.headersSent) {
      res.status(500).json({ error: err.message });
    } else if (!res.writableEnded) {
      res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
      res.write('data: [DONE]\n\n');
      res.end();
    }
  } finally {
    req.removeListener('close', abort);
    res.removeListener('close', abort);
  }
});

module.exports = router;
