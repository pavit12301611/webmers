const express = require('express');
const ragPipeline = require('../services/ragPipeline');
const config = require('../config');

const router = express.Router();

/**
 * POST /api/chat
 * RAG query endpoint with Server-Sent Events (SSE) streaming.
 * Supports AbortSignal via client disconnect, so the backend stops
 * generating when the browser closes the connection or hits Stop.
 */
router.post('/', async (req, res) => {
  const controller = new AbortController();
  const abort = () => controller.abort();
  req.on('close', abort);
  res.on('close', abort);

  try {
    const { query, conversationHistory = [], topK, chatModel, provider, embeddingModel } = req.body;
    const customApiKey = req.headers['x-api-key'] || req.headers['x-openai-api-key'] || req.headers['x-gemini-api-key'] || null;
    const activeProvider = req.headers['x-llm-provider'] || provider || null;

    if (!query || !query.trim()) {
      res.status(400).json({ error: 'Query string is required' });
      return;
    }

    if (typeof query !== 'string' || query.length > 10000) {
      res.status(400).json({ error: 'Query must be a string under 10,000 characters' });
      return;
    }

    await ragPipeline.processQueryAndStream({
      query,
      conversationHistory: Array.isArray(conversationHistory) ? conversationHistory : [],
      res,
      customApiKey,
      provider: activeProvider,
      topK: topK ? parseInt(topK, 10) : config.topK,
      chatModel: chatModel || null,
      embeddingModel: embeddingModel || null,
      signal: controller.signal
    });
  } catch (err) {
    if (controller.signal.aborted) return; // client left; nothing to write
    console.error('[Chat Route Error]:', err.message);
    if (!res.headersSent) {
      res.status(500).json({ error: err.message });
    } else if (!res.writableEnded) {
      res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
      res.write('data: [DONE]\n\n');
      res.end();
    }
  } finally {
    req.removeListener('close', abort);
    res.removeListener('close', abort);
  }
});

module.exports = router;
