const express = require('express');
const multer = require('multer');
const documentProcessor = require('../services/documentProcessor');
const config = require('../config');

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: config.maxUploadSizeMb * 1024 * 1024 }
});

/**
 * POST /api/upload
 * Upload PDF/TXT/MD/JSON/CSV/DOCX files or paste raw text notes.
 * Accepts multipart/form-data (files + chunkSize, chunkOverlap) or JSON
 * (title, rawText, chunkSize, chunkOverlap).
 */
router.post('/', upload.array('files', config.maxFilesPerUpload), async (req, res) => {
  try {
    const customApiKey = req.headers['x-api-key'] || req.headers['x-openai-api-key'] || req.headers['x-gemini-api-key'] || null;
    const provider = req.headers['x-llm-provider'] || req.body.provider || null;
    const embeddingModel = req.headers['x-embedding-model'] || req.body.embeddingModel || null;

    const chunkSize = req.body.chunkSize ? parseInt(req.body.chunkSize, 10) : config.chunkSize;
    const chunkOverlap = req.body.chunkOverlap ? parseInt(req.body.chunkOverlap, 10) : config.chunkOverlap;

    const results = [];
    const errors = [];

    if (req.files && req.files.length > 0) {
      for (const file of req.files) {
        try {
          const doc = await documentProcessor.processAndIndexDocument({
            file,
            customApiKey,
            provider,
            chunkSize,
            chunkOverlap,
            embeddingModel
          });
          results.push(doc);
        } catch (err) {
          errors.push({ filename: file.originalname, error: err.message });
        }
      }
    }

    if (req.body.rawText && req.body.rawText.trim()) {
      try {
        const doc = await documentProcessor.processAndIndexDocument({
          rawText: req.body.rawText,
          title: req.body.title || 'Pasted Note',
          customApiKey,
          provider,
          chunkSize,
          chunkOverlap,
          embeddingModel
        });
        results.push(doc);
      } catch (err) {
        errors.push({ title: req.body.title || 'Pasted Note', error: err.message });
      }
    }

    if (results.length === 0 && errors.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Failed to process document(s)',
        errors
      });
    }

    return res.json({
      success: true,
      processedCount: results.length,
      documents: results,
      errors: errors.length > 0 ? errors : undefined
    });
  } catch (err) {
    console.error('[Upload API Error]:', err.message);
    if (err instanceof multer.MulterError) {
      return res.status(400).json({ success: false, error: `Upload error: ${err.message}` });
    }
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
