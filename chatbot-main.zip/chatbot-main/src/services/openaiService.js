const { OpenAI } = require('openai');
const config = require('../config');
const { tokenize } = require('../utils/textNormalize');

class OpenAIService {
  getClient(customApiKey) {
    const apiKey = (customApiKey || config.openaiApiKey || '').trim();
    if (!apiKey) return null;
    return new OpenAI({ apiKey });
  }

  /** Deterministic local fallback pseudo-vector (unit norm) for keyless demo mode. */
  generateFallbackEmbedding(text, dimension = 1536) {
    const vector = new Array(dimension).fill(0);
    const words = tokenize(text);
    if (words.length === 0) words.push('empty');
    for (let i = 0; i < words.length; i++) {
      const word = words[i];
      let hash = 2166136261;
      for (let j = 0; j < word.length; j++) {
        hash ^= word.charCodeAt(j);
        hash = Math.imul(hash, 16777619);
      }
      vector[Math.abs(hash) % dimension] += 1.0 / Math.sqrt(words.length);
      if (i + 1 < words.length) {
        const bigram = word + ' ' + words[i + 1];
        let hash2 = 2166136261;
        for (let j = 0; j < bigram.length; j++) {
          hash2 ^= bigram.charCodeAt(j);
          hash2 = Math.imul(hash2, 16777619);
        }
        vector[Math.abs(hash2) % dimension] += 0.5 / Math.sqrt(words.length);
      }
    }
    const norm = Math.sqrt(vector.reduce((sum, val) => sum + val * val, 0)) || 1;
    return vector.map(val => val / norm);
  }

  /** Generate an embedding vector using the OpenAI embeddings API. */
  async getEmbedding(text, customApiKey = null, model = config.openaiEmbeddingModel) {
    const client = this.getClient(customApiKey);

    if (!client) {
      return {
        vector: this.generateFallbackEmbedding(text),
        isFallback: true,
        model: 'local-fallback-1536',
        dimension: 1536
      };
    }

    try {
      const response = await client.embeddings.create({
        model: model || config.openaiEmbeddingModel,
        input: text.replace(/\n/g, ' ')
      });
      const vector = response.data[0].embedding;
      return { vector, isFallback: false, model: model || config.openaiEmbeddingModel, dimension: vector.length };
    } catch (err) {
      console.error('[OpenAIService] Embedding error:', err.message);
      if (err.status === 401 || err.code === 'invalid_api_key') {
        throw new Error('Invalid OpenAI API Key. Please check your settings.');
      }
      return {
        vector: this.generateFallbackEmbedding(text),
        isFallback: true,
        errorNotice: err.message,
        model: 'local-fallback-1536',
        dimension: 1536
      };
    }
  }

  /** Stream RAG response via SSE, honoring an optional AbortSignal. */
  async streamChatCompletion(messages, res, customApiKey = null, model = config.openaiChatModel, signal = null) {
    const client = this.getClient(customApiKey);

    if (!res.headersSent) {
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      res.setHeader('X-Accel-Buffering', 'no');
    }

    const writeAborted = () => (signal && signal.aborted) || res.writableEnded || res.destroyed;

    if (!client) {
      const fallbackMsg = "⚠️ **OpenAI API Key Missing**\n\nI have retrieved relevant context snippets from your uploaded documents (see sources drawer below). To generate natural language AI completions, please configure a valid OpenAI API key in the **Settings** menu or in your backend `.env` file.";
      const words = fallbackMsg.split(' ');
      for (const word of words) {
        if (writeAborted()) break;
        res.write(`data: ${JSON.stringify({ content: word + ' ' })}\n\n`);
        await new Promise(r => setTimeout(r, 12));
      }
      if (!res.writableEnded) {
        res.write('data: [DONE]\n\n');
        res.end();
      }
      return;
    }

    try {
      const stream = await client.chat.completions.create({
        model: model || config.openaiChatModel,
        messages: messages.map(m => ({ role: m.role === 'system' ? 'system' : m.role === 'assistant' ? 'assistant' : 'user', content: m.content })),
        temperature: 0.2,
        stream: true,
        ...(signal ? { signal } : {})
      });

      for await (const chunk of stream) {
        if (writeAborted()) break;
        const content = chunk.choices[0]?.delta?.content || '';
        if (content) {
          res.write(`data: ${JSON.stringify({ content })}\n\n`);
        }
      }

      if (!res.writableEnded) {
        res.write('data: [DONE]\n\n');
        res.end();
      }
    } catch (err) {
      // AbortError from the client is expected when user stops generation
      if (err && (err.name === 'AbortError' || err.code === 'ABORT_ERR' || (signal && signal.aborted))) {
        if (!res.writableEnded) {
          res.write('data: [DONE]\n\n');
          res.end();
        }
        return;
      }
      console.error('[OpenAIService] Stream Chat Error:', err.message);
      if (!res.headersSent) {
        res.status(500).json({ error: err.message });
      } else if (!res.writableEnded) {
        res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`);
        res.write('data: [DONE]\n\n');
        res.end();
      }
    }
  }
}

module.exports = new OpenAIService();
