const fs = require('fs');
const path = require('path');
const config = require('../config');
const { tokenize } = require('../utils/textNormalize');

/**
 * PAVIT AI - Persistent embedded vector index.
 *
 * Improvements over the original:
 *  - Dimension-aware search: vectors store their embedding dimension + model, so
 *    switching AI providers mid-session no longer silently zeroes every score.
 *  - Hybrid scoring: combines cosine similarity with a lightweight lexical
 *    (keyword-overlap) score so retrieval stays useful even with local fallback
 *    embeddings and exact-term queries.
 *  - Upsert support: re-uploading the same file replaces the old vectors.
 *  - Atomic file writes (tmp + rename) so a crash can't corrupt the store.
 *  - Fast document stats without O(n) scans.
 */
class VectorDbService {
  constructor() {
    this.storePath = path.join(config.dataDir, 'vector_store.json');
    this.documents = new Map(); // docId -> docInfo
    this.vectors = [];          // Array of chunk objects
    this.initStore();
  }

  initStore() {
    try {
      if (!fs.existsSync(config.dataDir)) {
        fs.mkdirSync(config.dataDir, { recursive: true });
      }
      if (fs.existsSync(this.storePath)) {
        const rawData = fs.readFileSync(this.storePath, 'utf8');
        const parsed = JSON.parse(rawData);

        if (parsed.documents) {
          this.documents = new Map(Object.entries(parsed.documents));
        }
        if (Array.isArray(parsed.vectors)) {
          this.vectors = parsed.vectors;
        }
        console.log(`[VectorDB] Loaded store: ${this.documents.size} docs, ${this.vectors.length} vectors.`);
      } else {
        this.saveStore();
      }
    } catch (err) {
      console.error('[VectorDB] Error initializing store (starting fresh):', err.message);
      this.documents = new Map();
      this.vectors = [];
    }
  }

  saveStore() {
    try {
      if (!fs.existsSync(config.dataDir)) {
        fs.mkdirSync(config.dataDir, { recursive: true });
      }
      const data = {
        updatedAt: new Date().toISOString(),
        documents: Object.fromEntries(this.documents),
        vectors: this.vectors
      };
      const tmpPath = `${this.storePath}.tmp`;
      fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf8');
      fs.renameSync(tmpPath, this.storePath); // atomic on POSIX & Windows
    } catch (err) {
      console.error('[VectorDB] Error saving store:', err.message);
    }
  }

  /** Cosine similarity between two equal-length vectors. */
  cosineSimilarity(vecA, vecB) {
    if (!vecA || !vecB || vecA.length !== vecB.length || vecA.length === 0) return 0;
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < vecA.length; i++) {
      dotProduct += vecA[i] * vecB[i];
      normA += vecA[i] * vecA[i];
      normB += vecB[i] * vecB[i];
    }
    if (normA === 0 || normB === 0) return 0;
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }

  /**
   * Lightweight lexical similarity: weighted token overlap between query and chunk.
   * Boosts chunks that share rare/meaningful terms with the query.
   */
  lexicalScore(queryText, chunkText) {
    if (!queryText || !chunkText) return 0;
    const queryTokens = tokenize(queryText);
    if (queryTokens.length === 0) return 0;

    const chunkTokens = tokenize(chunkText);
    if (chunkTokens.length === 0) return 0;

    const chunkFreq = new Map();
    for (const t of chunkTokens) chunkFreq.set(t, (chunkFreq.get(t) || 0) + 1);

    let hits = 0;
    for (const t of queryTokens) {
      if (chunkFreq.has(t)) hits += 1 / Math.sqrt(chunkFreq.get(t)); // IDF-ish discount
    }
    const coverage = hits / queryTokens.length;
    return Math.min(1, coverage * 1.4); // slight boost, capped
  }

  /** Hybrid score = semanticWeight * cosine + lexicalWeight * lexical */
  hybridScore(queryVector, item, queryText) {
    const semantic = this.cosineSimilarity(queryVector, item.vector || item);
    const lexical = queryText ? this.lexicalScore(queryText, item.text || '') : 0;
    return config.semanticWeight * semantic + config.lexicalWeight * lexical;
  }

  /**
   * Upsert a processed document and its embedding chunks.
   * If a document with the same (originalName, size) exists it is replaced,
   * so re-uploading a file updates the knowledge base instead of duplicating it.
   */
  addDocument(docInfo, chunks) {
    // Upsert: remove any existing doc with the same name+size (unless same id)
    let replacedId = null;
    for (const [id, info] of this.documents.entries()) {
      if (id !== docInfo.id && info.originalName === docInfo.originalName && info.size === docInfo.size) {
        replacedId = id;
        break;
      }
    }
    if (replacedId) {
      this.documents.delete(replacedId);
      this.vectors = this.vectors.filter(v => v.docId !== replacedId);
      docInfo = { ...docInfo, replacedDocId: replacedId };
    }

    this.documents.set(docInfo.id, docInfo);

    for (const chunk of chunks) {
      this.vectors.push({
        id: chunk.id || `${docInfo.id}_chunk_${chunk.chunkIndex}`,
        docId: docInfo.id,
        docName: docInfo.originalName,
        chunkIndex: chunk.chunkIndex,
        text: chunk.text,
        vector: chunk.vector,
        dim: Array.isArray(chunk.vector) ? chunk.vector.length : 0,
        tokenCount: chunk.tokenCount || 0,
        metadata: {
          docId: docInfo.id,
          docName: docInfo.originalName,
          chunkIndex: chunk.chunkIndex,
          fileType: docInfo.fileType,
          createdAt: docInfo.createdAt,
          embeddingModel: chunk.embeddingModel || docInfo.embeddingModel || 'unknown'
        }
      });
    }

    this.saveStore();
    return {
      docId: docInfo.id,
      chunksAdded: chunks.length,
      totalVectors: this.vectors.length,
      replacedId
    };
  }

  /**
   * Top-K hybrid similarity search. Only vectors whose dimension matches the
   * query embedding are scored (prevents cross-provider dimension poisoning).
   */
  similaritySearch(queryVector, topK = config.topK, minScore = config.minScore, queryText = '') {
    if (!queryVector || !Array.isArray(queryVector) || this.vectors.length === 0) {
      return { results: [], totalScanned: 0, skippedDimensionMismatch: 0 };
    }
    const dim = queryVector.length;
    let skippedDimensionMismatch = 0;

    const scoredVectors = [];
    for (const item of this.vectors) {
      const itemDim = item.dim || (Array.isArray(item.vector) ? item.vector.length : 0);
      if (itemDim !== dim) {
        skippedDimensionMismatch++;
        continue;
      }
      const score = this.hybridScore(queryVector, item, queryText);
      scoredVectors.push({
        id: item.id,
        docId: item.docId,
        docName: item.docName,
        chunkIndex: item.chunkIndex,
        text: item.text,
        score: parseFloat(score.toFixed(4)),
        semanticScore: parseFloat(this.cosineSimilarity(queryVector, item.vector).toFixed(4)),
        lexicalScore: queryText ? parseFloat(this.lexicalScore(queryText, item.text || '').toFixed(4)) : 0,
        metadata: item.metadata
      });
    }

    const results = scoredVectors
      .filter(item => item.score >= minScore)
      .sort((a, b) => b.score - a.score)
      .slice(0, topK);

    return { results, totalScanned: scoredVectors.length, skippedDimensionMismatch };
  }

  /** List all registered documents with chunk counts. */
  getAllDocuments() {
    const chunkCounts = new Map();
    for (const v of this.vectors) {
      chunkCounts.set(v.docId, (chunkCounts.get(v.docId) || 0) + 1);
    }
    const list = [];
    for (const [id, info] of this.documents.entries()) {
      list.push({ ...info, chunkCount: chunkCounts.get(id) || 0 });
    }
    return list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  /** Get raw chunks for a document (for the inspector UI). */
  getDocumentChunks(docId, limit = 100) {
    return this.vectors
      .filter(v => v.docId === docId)
      .sort((a, b) => a.chunkIndex - b.chunkIndex)
      .slice(0, limit)
      .map(v => ({
        id: v.id,
        chunkIndex: v.chunkIndex,
        text: v.text,
        tokenCount: v.tokenCount || 0,
        embeddingModel: v.metadata?.embeddingModel || 'unknown'
      }));
  }

  deleteDocument(docId) {
    if (!this.documents.has(docId)) return false;
    this.documents.delete(docId);
    this.vectors = this.vectors.filter(v => v.docId !== docId);
    this.saveStore();
    return true;
  }

  clearAll() {
    this.documents.clear();
    this.vectors = [];
    this.saveStore();
    return true;
  }

  getStats() {
    const vectorDim = this.vectors.length > 0 && this.vectors[0].vector
      ? (this.vectors[0].dim || this.vectors[0].vector.length)
      : 0;

    // Detect dimension mix (provider switch without re-embed)
    const dims = new Set(this.vectors.map(v => v.dim || (v.vector && v.vector.length) || 0));
    const embeddingModels = new Set(this.vectors.map(v => v.metadata?.embeddingModel).filter(Boolean));

    let storageSize = 0;
    try {
      storageSize = fs.existsSync(this.storePath) ? fs.statSync(this.storePath).size : 0;
    } catch (_) { /* ignore */ }

    return {
      totalDocuments: this.documents.size,
      totalVectors: this.vectors.length,
      vectorDimension: vectorDim,
      dimensionsInUse: [...dims].filter(d => d > 0),
      embeddingModelsInUse: [...embeddingModels],
      embeddingModel: vectorDim
        ? (this.vectors[0].metadata?.embeddingModel || config.embeddingModelFor(config.llmProvider))
        : config.embeddingModelFor(config.llmProvider),
      mixedDimensions: dims.size > 1,
      storagePath: this.storePath,
      storageSizeBytes: storageSize,
      updatedAt: new Date().toISOString()
    };
  }
}

module.exports = new VectorDbService();
