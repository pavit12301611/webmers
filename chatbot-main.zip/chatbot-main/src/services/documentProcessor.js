const path = require('path');
const crypto = require('crypto');
const pdfParse = require('pdf-parse');
const mammoth = require('mammoth');
const { recursiveTextSplitter } = require('../utils/textSplitter');
const llmService = require('./llmService');
const vectorDbService = require('./vectorDbService');
const config = require('../config');

class DocumentProcessor {
  /**
   * Extract raw text from a file buffer based on extension/mime type.
   * Supported: PDF, TXT, MD, JSON, CSV, HTML, DOCX.
   */
  async extractText(fileBuffer, originalName, mimeType) {
    const ext = path.extname(originalName).toLowerCase();

    if (ext === '.pdf' || mimeType === 'application/pdf') {
      try {
        const pdfData = await pdfParse(fileBuffer);
        return pdfData.text || '';
      } catch (err) {
        throw new Error(`Failed to parse PDF file "${originalName}": ${err.message}`);
      }
    }

    if (ext === '.docx' || mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
      try {
        const result = await mammoth.extractRawText({ buffer: fileBuffer });
        return (result.value || '').trim();
      } catch (err) {
        throw new Error(`Failed to parse DOCX file "${originalName}": ${err.message}`);
      }
    }

    if (ext === '.json') {
      try {
        const jsonStr = fileBuffer.toString('utf8');
        const parsed = JSON.parse(jsonStr);
        return typeof parsed === 'string' ? parsed : JSON.stringify(parsed, null, 2);
      } catch (err) {
        return fileBuffer.toString('utf8');
      }
    }

    if (ext === '.html' || ext === '.htm' || mimeType === 'text/html') {
      return fileBuffer.toString('utf8')
        .replace(/<script[\s\S]*?<\/script>/gi, ' ')
        .replace(/<style[\s\S]*?<\/style>/gi, ' ')
        .replace(/<[^>]+>/g, ' ')
        .replace(/&nbsp;/g, ' ')
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/\s+/g, ' ')
        .trim();
    }

    // Default: plain text / markdown / csv
    return fileBuffer.toString('utf8');
  }

  /**
   * Process and index an uploaded file or raw text input.
   */
  async processAndIndexDocument({
    file = null,
    rawText = '',
    title = '',
    customApiKey = null,
    provider = null,
    chunkSize = config.chunkSize,
    chunkOverlap = config.chunkOverlap,
    embeddingModel = null
  }) {
    let originalName = title || 'Untitled Document';
    let fileType = 'text';
    let size = 0;
    let extractedText = '';

    if (file) {
      originalName = file.originalname;
      fileType = path.extname(file.originalname).replace('.', '').toUpperCase() || 'FILE';
      size = file.size;
      extractedText = await this.extractText(file.buffer, file.originalname, file.mimetype);
    } else if (rawText) {
      originalName = title || `Text Note (${new Date().toLocaleTimeString()})`;
      fileType = 'NOTE';
      size = Buffer.byteLength(rawText, 'utf8');
      extractedText = rawText;
    } else {
      throw new Error('No file or text content provided for processing.');
    }

    if (!extractedText || !extractedText.trim()) {
      throw new Error(`Document "${originalName}" is empty or could not be read.`);
    }

    const textChunks = recursiveTextSplitter(extractedText, chunkSize, chunkOverlap);
    if (textChunks.length === 0) {
      throw new Error(`Document "${originalName}" yielded 0 valid chunks.`);
    }

    const docId = `doc_${crypto.randomUUID().slice(0, 8)}`;
    const activeProvider = llmService.resolveProvider(provider);
    const effectiveEmbeddingModel = embeddingModel || config.embeddingModelFor(activeProvider);
    const processedChunks = [];

    // Generate embeddings for each chunk (sequential to respect API rate limits)
    for (let i = 0; i < textChunks.length; i++) {
      const embeddingResult = await llmService.getEmbedding(textChunks[i], customApiKey, activeProvider, effectiveEmbeddingModel);

      processedChunks.push({
        id: `${docId}_chunk_${i}`,
        chunkIndex: i,
        text: textChunks[i],
        vector: embeddingResult.vector,
        embeddingModel: embeddingResult.model || effectiveEmbeddingModel,
        tokenCount: Math.ceil(textChunks[i].length / 4)
      });
    }

    const docInfo = {
      id: docId,
      originalName,
      fileType,
      size,
      chunkCount: processedChunks.length,
      embeddingModel: processedChunks[0]?.embeddingModel || effectiveEmbeddingModel,
      provider: activeProvider,
      createdAt: new Date().toISOString()
    };

    const result = vectorDbService.addDocument(docInfo, processedChunks);

    return {
      docId,
      originalName,
      fileType,
      chunkCount: processedChunks.length,
      totalVectors: result.totalVectors,
      embeddingModel: docInfo.embeddingModel,
      provider: activeProvider,
      replacedId: result.replacedId || null,
      previewChunk: textChunks[0].slice(0, 200) + (textChunks[0].length > 200 ? '...' : '')
    };
  }
}

module.exports = new DocumentProcessor();
