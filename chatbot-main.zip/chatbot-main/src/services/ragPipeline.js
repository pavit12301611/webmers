const llmService = require('./llmService');
const vectorDbService = require('./vectorDbService');
const config = require('../config');

/**
 * PAVIT AI - RAG pipeline.
 *
 * Improvements over the original:
 *  - Conversation-aware retrieval: the query embedding is built from the user's
 *    question plus the most recent exchange, so follow-up questions ("what about
 *    the pricing?") retrieve the right context.
 *  - Hybrid retrieval: semantic + lexical scoring, with dimension-mismatch
 *    detection surfaced to the client.
 *  - Honours AbortSignal so the client "stop" button and disconnects work.
 *  - Sends richer SSE metadata (model used, retrieval stats).
 */
class RagPipeline {
  /**
   * Build a compact, embedding-friendly retrieval query from the raw question
   * and the last exchange of conversation history.
   */
  buildRetrievalQuery(query, conversationHistory = []) {
    const trimmedQuery = (query || '').trim();
    if (!Array.isArray(conversationHistory) || conversationHistory.length === 0) {
      return trimmedQuery;
    }
    // Grab the last assistant + user exchange only (bounded to avoid noise)
    const recent = conversationHistory.slice(-4).filter(m => m && m.content);
    if (recent.length === 0) return trimmedQuery;

    const contextBits = recent.map(m => {
      const role = m.role === 'user' ? 'User' : 'Assistant';
      const content = String(m.content || '').replace(/\s+/g, ' ').trim();
      return `${role}: ${content}`;
    }).join('\n').slice(0, 1200);

    return `${contextBits}\nCurrent question: ${trimmedQuery}`;
  }

  async processQueryAndStream({
    query,
    conversationHistory = [],
    res,
    customApiKey = null,
    provider = null,
    topK = config.topK,
    chatModel = null,
    embeddingModel = null,
    signal = null
  }) {
    if (!query || !query.trim()) {
      throw new Error('Query string cannot be empty.');
    }

    // Step 1: Embed a conversation-aware retrieval query
    const retrievalQuery = this.buildRetrievalQuery(query, conversationHistory);
    const queryEmbedding = await llmService.getEmbedding(retrievalQuery, customApiKey, provider, embeddingModel);

    // Step 2: Hybrid vector search (dimension-safe)
    const { results: searchResults, totalScanned, skippedDimensionMismatch } =
      vectorDbService.similaritySearch(queryEmbedding.vector, topK, config.minScore, query);

    // Prepare source citations
    const citations = searchResults.map((item, index) => ({
      citationId: index + 1,
      docId: item.docId,
      docName: item.docName,
      chunkIndex: item.chunkIndex,
      similarityScore: item.score,
      semanticScore: item.semanticScore,
      lexicalScore: item.lexicalScore,
      snippet: item.text
    }));

    // Step 3: SSE headers + initial metadata event
    if (!res.headersSent) {
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      res.setHeader('X-Accel-Buffering', 'no');
    }

    const providerName = llmService.resolveProvider(provider);
    const activeChatModel = chatModel || config.chatModelFor(providerName);

    res.write(`data: ${JSON.stringify({
      type: 'CITATIONS',
      citations,
      totalMatched: citations.length,
      totalScanned,
      skippedDimensionMismatch,
      provider: providerName,
      chatModel: activeChatModel,
      embeddingModel: queryEmbedding.model || config.embeddingModelFor(providerName),
      embeddingFallback: queryEmbedding.isFallback === true
    })}\n\n`);

    if (skippedDimensionMismatch > 0 && searchResults.length === 0) {
      res.write(`data: ${JSON.stringify({
        type: 'NOTICE',
        message: `Your knowledge base contains ${skippedDimensionMismatch} vector(s) created with a different embedding model/dimension. Uploaded content embedded with the current provider (${providerName}) will be searchable; re-upload old files or clear the store to rebuild.`
      })}\n\n`);
    }

    // Step 4: Build context block & system prompt
    let contextBlock = '';
    if (searchResults.length === 0) {
      contextBlock = 'No relevant document context found in the uploaded Knowledge Base.';
    } else {
      contextBlock = searchResults.map((item, idx) => {
        return `--- SOURCE [${idx + 1}]: Document "${item.docName}" (Chunk ${item.chunkIndex + 1}, match ${(item.score * 100).toFixed(1)}%) ---\n${item.text}`;
      }).join('\n\n');
    }

    const systemPrompt = `You are PAVIT, an intelligent, precise AI assistant answering user questions based ONLY on the provided document context from the user's Knowledge Base dashboard.

CRITICAL INSTRUCTIONS:
1. Ground your answers strictly on the facts, details, and context provided below.
2. If the answer cannot be determined or inferred from the provided context, state clearly: "Based on your uploaded documents, I couldn't find specific information regarding this." and then offer any related insights if available.
3. Be conversational and concise. Use Markdown formatting (headings, bolding, lists, code blocks) where helpful.
4. Always cite your sources naturally (e.g. "[Source 1]" or mentioning document names) when asserting facts.
5. Never invent URLs, dates, numbers, or policies that are not present in the context.

CONTEXT FROM UPLOADED DOCUMENTS:
${contextBlock}`;

    const messages = [
      { role: 'system', content: systemPrompt },
      ...conversationHistory.slice(-6).map(msg => ({
        role: msg.role === 'user' ? 'user' : 'assistant',
        content: msg.content
      })),
      { role: 'user', content: query }
    ];

    // Step 5: Stream the completion through the active provider
    await llmService.streamChatCompletion(messages, res, customApiKey, activeChatModel, providerName, signal);
  }
}

module.exports = new RagPipeline();
