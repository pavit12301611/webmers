const { GoogleGenerativeAI } = require('@google/generative-ai');
const config = require('../config');
const { tokenize } = require('../utils/textNormalize');

const KNOWN_LEGACY = new Set(['latest', 'gemini-latest', 'gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-2.0-flash-lite']);

class GeminiService {
  getApiKey(customApiKey) {
    const key = (customApiKey || config.geminiApiKey || '').trim();
    return key || null;
  }

  /**
   * Normalize a model name to a `models/...` resource string.
   * Real gemini models (e.g. gemini-2.5-flash, gemini-2.0-flash) pass through;
   * only unknown/legacy aliases fall back to the auto-updating flash alias.
   */
  formatModelName(modelName, defaultName, isEmbedding = false) {
    let name = (modelName || defaultName || '').trim();
    if (!name) name = isEmbedding ? 'models/gemini-embedding-001' : 'models/gemini-flash-latest';

    if (isEmbedding) {
      if (name === 'text-embedding-004' || name === 'gemini-embedding-001') {
        return 'models/gemini-embedding-001';
      }
    }

    if (KNOWN_LEGACY.has(name) || !/^gemini/i.test(name)) {
      name = 'gemini-flash-latest';
    }
    if (!name.startsWith('models/')) {
      name = `models/${name}`;
    }
    return name;
  }

  /**
   * Deterministic local fallback vector generator (used when no valid API key).
   * Produces unit-norm vectors so cosine similarity behaves correctly.
   */
  generateFallbackEmbedding(text, dimension = 768) {
    const vector = new Array(dimension).fill(0);
    const words = tokenize(text);
    if (words.length === 0) words.push('empty');
    for (let i = 0; i < words.length; i++) {
      const word = words[i];
      let hash = 2166136261;
      for (let j = 0; j < word.length; j++) {
        hash ^= word.charCodeAt(j);
        hash = Math.imul(hash, 16777619);
      }
      const index = Math.abs(hash) % dimension;
      vector[index] += 1.0 / Math.sqrt(words.length);
      // small bigram contribution for better semantics
      if (i + 1 < words.length) {
        const bigram = word + ' ' + words[i + 1];
        let hash2 = 2166136261;
        for (let j = 0; j < bigram.length; j++) {
          hash2 ^= bigram.charCodeAt(j);
          hash2 = Math.imul(hash2, 16777619);
        }
        vector[Math.abs(hash2) % dimension] += 0.5 / Math.sqrt(words.length);
      }
    }
    const norm = Math.sqrt(vector.reduce((sum, val) => sum + val * val, 0)) || 1;
    return vector.map(val => val / norm);
  }

  /**
   * Generate an embedding vector using the Gemini embedding API.
   * Returns { vector, isFallback, errorNotice, model, dimension }.
   */
  async getEmbedding(text, customApiKey = null, modelName = config.geminiEmbeddingModel) {
    const apiKey = this.getApiKey(customApiKey);

    if (!apiKey) {
      return {
        vector: this.generateFallbackEmbedding(text),
        isFallback: true,
        model: 'local-fallback-768',
        dimension: 768
      };
    }

    try {
      const genAI = new GoogleGenerativeAI(apiKey);
      const targetModel = this.formatModelName(modelName, config.geminiEmbeddingModel, true);
      const embedModel = genAI.getGenerativeModel({ model: targetModel });
      const result = await embedModel.embedContent(text.replace(/\n/g, ' '));
      const embeddingValues = result?.embedding?.values;

      if (!embeddingValues || !Array.isArray(embeddingValues)) {
        throw new Error('Gemini API did not return valid embedding values.');
      }

      return {
        vector: embeddingValues,
        isFallback: false,
        model: targetModel,
        dimension: embeddingValues.length
      };
    } catch (err) {
      console.error('[GeminiService] Embedding error:', err.message);
      let userNotice = err.message;
      if (
        err.message.includes('UNAUTHENTICATED') ||
        err.message.includes('401') ||
        err.message.includes('400 Bad Request') ||
        err.message.includes('API key not valid') ||
        err.message.includes('API_KEY_INVALID') ||
        err.message.includes('invalid authentication credentials')
      ) {
        userNotice = 'Invalid Google Gemini API Key. Please get an API Key from Google AI Studio (https://aistudio.google.com/app/apikey) and set GEMINI_API_KEY in your .env file or Settings UI.';
      }
      return {
        vector: this.generateFallbackEmbedding(text),
        isFallback: true,
        errorNotice: userNotice,
        model: 'local-fallback-768',
        dimension: 768
      };
    }
  }

  /**
   * Stream Gemini response back to the Express response using SSE.
   * Honors an optional AbortSignal (client disconnect / stop button).
   */
  async streamChatCompletion(messages, res, customApiKey = null, modelName = config.geminiChatModel, signal = null) {
    const apiKey = this.getApiKey(customApiKey);

    if (!res.headersSent) {
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      res.setHeader('X-Accel-Buffering', 'no');
    }

    const writeAborted = () => (signal && signal.aborted) || res.writableEnded || res.destroyed;

    if (!apiKey) {
      const fallbackMsg = "⚠️ **Google Gemini API Key Missing**\n\nI have retrieved relevant document context snippets from your Knowledge Base (see sources below). To generate AI answers using Google Gemini, please get an API Key from **https://aistudio.google.com/app/apikey** and add it to your `.env` file (`GEMINI_API_KEY=...`) or the Settings menu.";
      const words = fallbackMsg.split(' ');
      for (const word of words) {
        if (writeAborted()) break;
        res.write(`data: ${JSON.stringify({ content: word + ' ' })}\n\n`);
        await new Promise(r => setTimeout(r, 12));
      }
      if (!res.writableEnded) {
        res.write('data: [DONE]\n\n');
        res.end();
      }
      return;
    }

    try {
      const genAI = new GoogleGenerativeAI(apiKey);
      const targetModel = this.formatModelName(modelName, config.geminiChatModel, false);

      const systemMessage = messages.find(m => m.role === 'system')?.content || '';
      const userAndAssistantMsgs = messages.filter(m => m.role !== 'system');

      const model = genAI.getGenerativeModel({
        model: targetModel,
        systemInstruction: systemMessage ? { parts: [{ text: systemMessage }] } : undefined
      });

      // Gemini requires alternating user/model roles; merge consecutive same-role messages.
      const contents = [];
      for (const msg of userAndAssistantMsgs) {
        const role = msg.role === 'user' ? 'user' : 'model';
        const text = msg.content || '';
        const last = contents[contents.length - 1];
        if (last && last.role === role) {
          last.parts[0].text += '\n' + text;
        } else {
          contents.push({ role, parts: [{ text }] });
        }
      }
      if (contents.length === 0 || contents[contents.length - 1].role !== 'user') {
        contents.push({ role: 'user', parts: [{ text: 'Continue.' }] });
      }

      const result = await model.generateContentStream({ contents });

      for await (const chunk of result.stream) {
        if (writeAborted()) break;
        const text = chunk.text();
        if (text) {
          res.write(`data: ${JSON.stringify({ content: text })}\n\n`);
        }
      }

      if (!res.writableEnded) {
        res.write('data: [DONE]\n\n');
        res.end();
      }
    } catch (err) {
      console.error('[GeminiService] Stream Error:', err.message);
      let userFriendlyErr = err.message;
      if (
        err.message.includes('UNAUTHENTICATED') ||
        err.message.includes('401') ||
        err.message.includes('400 Bad Request') ||
        err.message.includes('API key not valid') ||
        err.message.includes('API_KEY_INVALID') ||
        err.message.includes('invalid authentication credentials')
      ) {
        userFriendlyErr = 'Invalid Google Gemini API Key. Please generate a key at https://aistudio.google.com/app/apikey and set GEMINI_API_KEY in your .env file.';
      }

      if (!res.headersSent) {
        res.status(500).json({ error: userFriendlyErr });
      } else if (!res.writableEnded) {
        res.write(`data: ${JSON.stringify({ error: userFriendlyErr })}\n\n`);
        res.write('data: [DONE]\n\n');
        res.end();
      }
    }
  }
}

module.exports = new GeminiService();
