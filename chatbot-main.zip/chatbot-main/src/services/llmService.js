const config = require('../config');
const geminiService = require('./geminiService');
const openAiService = require('./openaiService');

/**
 * PAVIT AI - Unified multi-provider factory ('gemini' | 'openai')
 */
class LlmService {
  /**
   * Resolve active provider from header, body or config default.
   */
  resolveProvider(headerProvider = null) {
    if (headerProvider && (headerProvider === 'gemini' || headerProvider === 'openai')) {
      return headerProvider;
    }
    return config.llmProvider === 'gemini' ? 'gemini' : 'openai';
  }

  /**
   * Get an embedding vector, delegating to the active provider.
   * @param {string} text
   * @param {string|null} customApiKey
   * @param {string|null} provider
   * @param {string|null} embeddingModel optional model override
   */
  async getEmbedding(text, customApiKey = null, provider = null, embeddingModel = null) {
    const activeProvider = this.resolveProvider(provider);
    const model = embeddingModel || config.embeddingModelFor(activeProvider);

    if (activeProvider === 'gemini') {
      return geminiService.getEmbedding(text, customApiKey, model);
    }
    return openAiService.getEmbedding(text, customApiKey, model);
  }

  /**
   * Stream a chat completion, delegating to the active provider.
   */
  async streamChatCompletion(messages, res, customApiKey = null, model = null, provider = null, signal = null) {
    const activeProvider = this.resolveProvider(provider);
    const activeModel = model || config.chatModelFor(activeProvider);

    if (activeProvider === 'gemini') {
      return geminiService.streamChatCompletion(messages, res, customApiKey, activeModel, signal);
    }
    return openAiService.streamChatCompletion(messages, res, customApiKey, activeModel, signal);
  }

  /**
   * Get active provider metadata & health status.
   */
  getProviderInfo() {
    const provider = this.resolveProvider();
    return {
      provider,
      isGemini: provider === 'gemini',
      isOpenAI: provider === 'openai',
      geminiModel: config.geminiChatModel,
      geminiEmbeddingModel: config.geminiEmbeddingModel,
      openaiModel: config.openaiChatModel,
      openaiEmbeddingModel: config.openaiEmbeddingModel,
      activeEmbeddingModel: config.embeddingModelFor(provider),
      hasGeminiApiKey: Boolean(config.geminiApiKey),
      hasOpenAiApiKey: Boolean(config.openaiApiKey),
      builtBy: config.builtBy
    };
  }
}

module.exports = new LlmService();
