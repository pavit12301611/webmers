const llmService = require('./llmService');
const vectorDbService = require('./vectorDbService');
const config = require('../config');

/**
 * PAVIT AI - Standard Operating Procedure (SOP) generator.
 * Uses the same RAG retrieval as chat but with an SOP-authoring system prompt.
 */
class SopService {
  buildCitations(searchResults) {
    return searchResults.map((item, index) => ({
      citationId: index + 1,
      docId: item.docId,
      docName: item.docName,
      chunkIndex: item.chunkIndex,
      similarityScore: item.score,
      semanticScore: item.semanticScore,
      lexicalScore: item.lexicalScore,
      snippet: item.text
    }));
  }

  buildContextBlock(searchResults) {
    if (!searchResults.length) {
      return 'No relevant document context was found in the uploaded Knowledge Base.';
    }
    return searchResults
      .map((item, idx) => {
        return `--- SOURCE [${idx + 1}]: Document "${item.docName}" (Chunk ${item.chunkIndex + 1}, match ${(item.score * 100).toFixed(1)}%) ---\n${item.text}`;
      })
      .join('\n\n');
  }

  buildSystemPrompt(contextBlock) {
    return `You are PAVIT, a Standard Operating Procedure (SOP) writer. Generate a clear, actionable SOP using only the provided document context. Structure your answer with sections such as Purpose, Scope, Roles, Tools, Procedures / Steps, and Notes. Use numbered steps, keep instructions concise, and cite relevant sources when referencing details from the documents. Do not hallucinate facts or invent details not present in the context.

DOCUMENT CONTEXT:
${contextBlock}`;
  }

  async streamSop({
    query,
    res,
    customApiKey = null,
    provider = null,
    topK = config.topK,
    chatModel = null,
    embeddingModel = null,
    signal = null
  }) {
    if (!query || !query.trim()) {
      throw new Error('Query string cannot be empty.');
    }

    const queryEmbedding = await llmService.getEmbedding(query, customApiKey, provider, embeddingModel);
    const { results: searchResults, skippedDimensionMismatch } =
      vectorDbService.similaritySearch(queryEmbedding.vector, topK, config.minScore, query);
    const citations = this.buildCitations(searchResults);

    if (!res.headersSent) {
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      res.setHeader('X-Accel-Buffering', 'no');
    }

    const providerName = llmService.resolveProvider(provider);
    res.write(`data: ${JSON.stringify({
      type: 'CITATIONS',
      citations,
      totalMatched: citations.length,
      skippedDimensionMismatch,
      provider: providerName,
      chatModel: chatModel || config.chatModelFor(providerName),
      mode: 'sop'
    })}\n\n`);

    const contextBlock = this.buildContextBlock(searchResults);
    const systemPrompt = this.buildSystemPrompt(contextBlock);

    const messages = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: query }
    ];

    await llmService.streamChatCompletion(messages, res, customApiKey, chatModel, providerName, signal);
  }
}

module.exports = new SopService();
