const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

const CHUNK_OVERLAP_LIMIT = 0.5; // overlap cannot exceed 50% of chunk size

function clamp(value, min, max, fallback) {
  const n = parseInt(value, 10);
  if (Number.isNaN(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

module.exports = {
  appName: process.env.APP_NAME || 'PAVIT AI',
  builtBy: 'PAVIT',
  version: '2.0.0',

  port: parseInt(process.env.PORT || '5001', 10),
  corsOrigin: process.env.CORS_ORIGIN || '*',

  // Provider Selection: 'gemini' or 'openai'
  llmProvider: (process.env.LLM_PROVIDER || 'gemini').toLowerCase(),

  // Gemini Configuration
  geminiApiKey: process.env.GEMINI_API_KEY || '',
  geminiChatModel: process.env.DEFAULT_GEMINI_CHAT_MODEL || 'gemini-flash-latest',
  geminiEmbeddingModel: process.env.DEFAULT_GEMINI_EMBEDDING_MODEL || 'gemini-embedding-001',

  // OpenAI Configuration
  openaiApiKey: process.env.OPENAI_API_KEY || '',
  openaiChatModel: process.env.DEFAULT_OPENAI_CHAT_MODEL || 'gpt-4o-mini',
  openaiEmbeddingModel: process.env.DEFAULT_OPENAI_EMBEDDING_MODEL || 'text-embedding-3-small',

  // RAG Parameters (clamped for safety)
  chunkSize: clamp(process.env.DEFAULT_CHUNK_SIZE, 200, 4000, 800),
  chunkOverlap: clamp(process.env.DEFAULT_CHUNK_OVERLAP, 0, 1000, 150),
  topK: clamp(process.env.DEFAULT_TOP_K, 1, 20, 4),
  minScore: parseFloat(process.env.DEFAULT_MIN_SCORE || '0.05', 10),

  // Hybrid search weighting (lexical vs semantic)
  lexicalWeight: parseFloat(process.env.LEXICAL_WEIGHT || '0.35', 10),
  semanticWeight: parseFloat(process.env.SEMANTIC_WEIGHT || '0.65', 10),

  // Server protection
  rateLimitWindowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '60000', 10),
  rateLimitMax: parseInt(process.env.RATE_LIMIT_MAX || '60', 10),
  maxUploadSizeMb: parseInt(process.env.MAX_UPLOAD_SIZE_MB || '25', 10),
  maxFilesPerUpload: parseInt(process.env.MAX_FILES_PER_UPLOAD || '10', 10),

  // Directories
  dataDir: path.join(__dirname, '../data'),
  uploadsDir: path.join(__dirname, '../uploads'),

  /**
   * Resolve embedding model for a given provider
   */
  embeddingModelFor(provider) {
    return provider === 'gemini' ? this.geminiEmbeddingModel : this.openaiEmbeddingModel;
  },

  /**
   * Resolve chat model for a given provider
   */
  chatModelFor(provider) {
    return provider === 'gemini' ? this.geminiChatModel : this.openaiChatModel;
  }
};
