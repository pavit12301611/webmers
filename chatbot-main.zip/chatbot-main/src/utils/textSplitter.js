/**
 * PAVIT AI - Recursive, heading-aware text splitter designed for RAG chunking.
 *
 * Improvements over the original:
 *  - Markdown heading detection: sections are split on `#` headings first and each
 *    chunk carries its heading chain as context (huge win for retrieval quality).
 *  - Overlap is clamped so it can never exceed 50% of chunk size (prevents
 *    degenerate loops and runaway memory).
 *  - Splits on paragraph, sentence and word boundaries before hard-splitting.
 *  - Guarantees non-empty chunks and never produces an infinite loop.
 */

function clampOverlap(chunkSize, chunkOverlap) {
  if (!Number.isFinite(chunkSize) || chunkSize <= 0) chunkSize = 800;
  if (!Number.isFinite(chunkOverlap) || chunkOverlap < 0) chunkOverlap = 0;
  return Math.min(chunkOverlap, Math.floor(chunkSize * 0.5));
}

/**
 * Extract markdown heading lines (e.g. "## Installation") with their level.
 */
function extractHeadings(text) {
  const headings = [];
  const regex = /^(#{1,6})\s+(.+?)\s*$/gm;
  let match;
  while ((match = regex.exec(text)) !== null) {
    headings.push({
      level: match[1].length,
      text: match[2].trim(),
      index: match.index,
      length: match[0].length
    });
  }
  return headings;
}

/**
 * Split a markdown-ish document into sections delimited by headings.
 * Returns [{ headingChain, body }] where headingChain is the nested context.
 */
function splitByHeadings(text) {
  const headings = extractHeadings(text);
  if (headings.length === 0) {
    return [{ headingChain: '', body: text }];
  }

  const sections = [];
  for (let i = 0; i < headings.length; i++) {
    const start = headings[i].index;
    const end = i + 1 < headings.length ? headings[i + 1].index : text.length;
    sections.push({
      heading: headings[i],
      body: text.slice(start + headings[i].length, end).trim()
    });
  }

  // Build heading chains: a section inherits all ancestor headings
  const chainStack = [];
  const result = [];
  for (const section of sections) {
    while (chainStack.length && chainStack[chainStack.length - 1].level >= section.heading.level) {
      chainStack.pop();
    }
    chainStack.push({ level: section.heading.level, text: section.heading.text });
    const headingChain = chainStack.map(h => h.text).join(' > ');
    if (section.body.length > 0) {
      result.push({ headingChain, body: section.body });
    } else {
      // heading with no body yet - keep as chain context for the next section
      result.push({ headingChain, body: '' });
    }
  }
  // Drop empty bodies that were only kept for context (they were already merged into chain)
  return result.filter(s => s.body.length > 0).length > 0
    ? result.filter(s => s.body.length > 0)
    : [{ headingChain: headings.map(h => h.text).join(' > '), body: text }];
}

function splitTextInternal(str, seps, chunkSize, chunkOverlap) {
  if (!str || str.length === 0) return [];
  if (str.length <= chunkSize) return [str];

  let bestSep = '';
  for (const sep of seps) {
    if (str.includes(sep)) {
      bestSep = sep;
      break;
    }
  }

  if (!bestSep) {
    // Hard split fallback (no separator found)
    const chunks = [];
    let start = 0;
    while (start < str.length) {
      const end = Math.min(str.length, start + chunkSize);
      chunks.push(str.slice(start, end));
      if (end >= str.length) break;
      start = end - chunkOverlap;
      if (start >= end) break; // safety: overlap clamped by caller, but guard anyway
    }
    return chunks;
  }

  const parts = str.split(bestSep);
  const chunks = [];
  let currentChunk = '';

  for (let i = 0; i < parts.length; i++) {
    const part = parts[i];
    if (!part) continue;
    const candidate = currentChunk ? currentChunk + bestSep + part : part;

    if (candidate.length <= chunkSize) {
      currentChunk = candidate;
    } else {
      if (currentChunk) chunks.push(currentChunk);
      if (part.length > chunkSize) {
        const subSepIndex = seps.indexOf(bestSep) + 1;
        const remainingSeps = seps.slice(subSepIndex);
        const subChunks = splitTextInternal(part, remainingSeps, chunkSize, chunkOverlap);
        if (subChunks.length > 1) {
          chunks.push(...subChunks.slice(0, -1));
          currentChunk = subChunks[subChunks.length - 1] || part;
        } else {
          currentChunk = part;
        }
      } else {
        currentChunk = part;
      }
    }
  }

  if (currentChunk) chunks.push(currentChunk);

  // Apply overlap between adjacent chunks (clamped upstream)
  const result = [];
  for (let i = 0; i < chunks.length; i++) {
    let chunkStr = chunks[i];
    if (i > 0 && chunkOverlap > 0) {
      const prevChunk = chunks[i - 1];
      const overlapSnippet = prevChunk.slice(Math.max(0, prevChunk.length - chunkOverlap));
      chunkStr = overlapSnippet + bestSep + chunkStr;
    }
    chunkStr = chunkStr.trim();
    if (chunkStr.length > 0) result.push(chunkStr);
  }
  return result;
}

/**
 * Recursive, heading-aware text splitter.
 * @param {string} text
 * @param {number} chunkSize max characters per chunk
 * @param {number} chunkOverlap overlap in characters between adjacent chunks
 * @returns {string[]}
 */
function recursiveTextSplitter(text, chunkSize = 800, chunkOverlap = 150) {
  if (!text || typeof text !== 'string') return [];

  chunkOverlap = clampOverlap(chunkSize, chunkOverlap);

  const cleanedText = text.replace(/\r\n/g, '\n').trim();
  if (!cleanedText) return [];
  if (cleanedText.length <= chunkSize) return [cleanedText];

  const separators = ['\n\n', '\n', '. ', '? ', '! ', '; ', ', ', ' '];
  const sections = splitByHeadings(cleanedText);
  const chunks = [];

  for (const section of sections) {
    let body = section.body;
    if (!body) continue;

    if (section.headingChain) {
      // Reserve room for heading context within the chunk budget
      const prefix = `[${section.headingChain}]\n`;
      const effectiveSize = Math.max(200, chunkSize - prefix.length);
      const sectionChunks = splitTextInternal(body, separators, effectiveSize, chunkOverlap);
      for (const chunk of sectionChunks) {
        chunks.push(prefix + chunk);
      }
    } else {
      chunks.push(...splitTextInternal(body, separators, chunkSize, chunkOverlap));
    }
  }

  return chunks.filter(c => c && c.trim().length > 0);
}

module.exports = {
  recursiveTextSplitter,
  extractHeadings
};
