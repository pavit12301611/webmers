# ⚡ PAVIT AI — Multi-Agent Document Chatbot & Knowledge Dashboard

> **Built by PAVIT** · v2.0

A modern, full-stack **Retrieval-Augmented Generation (RAG)** web application built with **Node.js**, **Express**, **React (Vite)**, and an **Embedded Persistent Vector Database**.

Upload your documents (PDF, TXT, Markdown, JSON, CSV, DOCX, HTML) or paste text notes into the dashboard, then chat with PAVIT — an AI assistant that answers **strictly grounded in your knowledge base**, with exact **Source Citations**, hybrid retrieval scores, and streaming responses.

Supports **Google Gemini** and **OpenAI** as configurable AI agent providers, switchable at runtime.

---

## ✨ What's inside (v2.0 upgrades)

### Core RAG engine
- **Heading-aware chunking** — markdown headings become section context so chunks keep their structure (`[Section > Subsection]` prefix).
- **Hybrid retrieval** — semantic (cosine) + keyword (lexical) scoring, so exact-term queries work even without an API key.
- **Dimension-safe vector store** — every chunk records its embedding model & dimension; switching providers mid-session no longer silently breaks search (with visible warnings).
- **Conversation-aware retrieval** — follow-up questions ("what about pricing?") are embedded together with the latest exchange, so they retrieve the right context.
- **Atomic, persistent store** — `data/vector_store.json` written via tmp+rename; upsert dedupe replaces re-uploaded files instead of duplicating them.
- **.docx / HTML support** added on top of PDF / TXT / MD / JSON / CSV.

### Chat experience
- **Chat sessions** — multiple conversations, saved locally, with rename / delete / switch (sidebar).
- **Stop generation** — abort mid-stream (backend + client disconnect handling).
- **Regenerate answer** — re-roll the last answer.
- **Full Markdown rendering** — headings, lists, tables, blockquotes, code blocks with copy button (react-markdown + GFM).
- **SOP Generator mode** — one click turns your documents into a structured Standard Operating Procedure.

### Dashboard & settings
- Per-provider **API keys, chat models and embedding models** stored locally, verified against the live API.
- Document inspector with **raw chunk viewer**, embedding model, token counts.
- Vector store stats: dimensions in use, storage size, mixed-dimension warnings, provider health.
- Rate limiting, input validation, and security headers on the API.

---

## Architecture

```
pavit-ai/
├── package.json                # Root package (build & serve scripts)
├── server.js                   # Express API + React SPA static server
├── .env.example                # Environment template
├── src/
│   ├── config.js               # Env loader + safe defaults (clamped values)
│   ├── routes/
│   │   ├── upload.js           # File & text-note ingestion (PDF/TXT/MD/JSON/CSV/DOCX/HTML)
│   │   ├── documents.js        # Document listing, delete, chunk inspector
│   │   ├── chat.js             # RAG query with SSE streaming + abort support
│   │   ├── sop.js              # SOP generator endpoint (SSE)
│   │   ├── stats.js            # Analytics & provider health
│   │   └── settings.js         # API key verification handler
│   ├── services/
│   │   ├── llmService.js       # Unified multi-provider factory
│   │   ├── geminiService.js    # Gemini chat + embeddings (with abort support)
│   │   ├── openaiService.js    # OpenAI chat + embeddings (with abort support)
│   │   ├── vectorDbService.js  # Dimension-aware persistent vector index (hybrid scoring)
│   │   ├── documentProcessor.js# Text extraction + heading-aware chunking
│   │   ├── ragPipeline.js      # Retrieval + context prompt synthesis
│   │   └── sopService.js       # SOP authoring pipeline
│   └── utils/
│       └── textSplitter.js     # Heading-aware recursive chunker
├── data/                       # Local vector database (vector_store.json)
└── frontend/                   # React + Vite SPA
    └── src/
        ├── App.jsx             # Sessions, provider state, streaming orchestration
        ├── components/
        │   ├── Navbar.jsx
        │   ├── Chat/
        │   │   ├── ChatWindow.jsx
        │   │   ├── ChatInput.jsx      # Stop button + SOP toggle
        │   │   ├── MessageItem.jsx    # Full Markdown rendering
        │   │   ├── SourceCitations.jsx
        │   │   └── SessionSidebar.jsx
        │   └── Dashboard/
        │       ├── DocumentUploader.jsx
        │       ├── DocumentList.jsx    # Chunk inspector
        │       ├── VectorStats.jsx
        │       └── SettingsModal.jsx  # Per-provider keys & models
        └── services/api.js
```

---

## Getting Started

### Prerequisites
- **Node.js** ≥ 18, **npm** ≥ 9
- An API key from either **Google AI Studio** (free) or **OpenAI**

### Install

```bash
npm install          # installs root + frontend deps
```

### Configure

```bash
cp .env.example .env
# then edit .env with your provider & keys
```

```env
LLM_PROVIDER=gemini
GEMINI_API_KEY=your_gemini_api_key_here
DEFAULT_GEMINI_CHAT_MODEL=gemini-flash-latest
DEFAULT_GEMINI_EMBEDDING_MODEL=gemini-embedding-001

OPENAI_API_KEY=your_openai_api_key_here
DEFAULT_OPENAI_CHAT_MODEL=gpt-4o-mini
DEFAULT_OPENAI_EMBEDDING_MODEL=text-embedding-3-small

PORT=5001
```

### Run

| Command | What it does |
| :--- | :--- |
| `npm run serve` | Build frontend, then serve everything on `http://localhost:5001` |
| `npm run dev` | Backend only (auto-reload) — run `npm run dev --prefix frontend` too for Vite HMR on :3000 |
| `npm run build` | Build the production frontend bundle |
| `npm start` | Start the server (assumes a prior build) |

**No API key?** PAVIT falls back to local deterministic embeddings so you can still index documents, run hybrid retrieval, and see the whole pipeline working — then add a key in Settings when you want real AI answers.

---

## API Endpoints

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/health` | Server health, provider & uptime |
| `POST` | `/api/upload` | Upload files or paste raw text (multipart or JSON) |
| `GET` | `/api/documents` | List documents & chunk counts |
| `GET` | `/api/documents/:id/chunks` | Raw chunk texts for the inspector |
| `DELETE` | `/api/documents/:id` | Delete doc (or `all` to clear store) |
| `POST` | `/api/chat` | RAG query with SSE streaming |
| `POST` | `/api/sop` | SOP generator with SSE streaming |
| `GET` | `/api/stats` | Analytics, provider health, embedding info |
| `POST` | `/api/settings/verify-key` | Validate a Gemini/OpenAI API key |

---

## Notes

- API keys entered in Settings are stored in **localStorage only** (per-provider) and sent to the backend per request; the server also reads its own `.env` keys as fallback.
- `data/` and `frontend/dist/` are git-ignored — your vector store stays local.
- License: MIT.
