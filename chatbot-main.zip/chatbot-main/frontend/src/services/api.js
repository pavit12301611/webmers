const API_BASE = '/api';

function sseHeaders(apiKey, provider, embeddingModel) {
  const headers = { 'Content-Type': 'application/json' };
  if (apiKey) headers['x-api-key'] = apiKey;
  if (provider) headers['x-llm-provider'] = provider;
  if (embeddingModel) headers['x-embedding-model'] = embeddingModel;
  return headers;
}

export async function getDocuments() {
  const res = await fetch(`${API_BASE}/documents`);
  if (!res.ok) throw new Error('Failed to fetch documents');
  return res.json();
}

export async function uploadFiles(files, apiKey = null, provider = null, options = {}) {
  const formData = new FormData();
  for (const file of files) {
    formData.append('files', file);
  }
  if (options.chunkSize) formData.append('chunkSize', options.chunkSize);
  if (options.chunkOverlap) formData.append('chunkOverlap', options.chunkOverlap);

  const headers = sseHeaders(apiKey, provider, options.embeddingModel);

  const res = await fetch(`${API_BASE}/upload`, {
    method: 'POST',
    headers,
    body: formData
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.message || errData.error || 'Failed to upload files');
  }

  return res.json();
}

export async function uploadRawText(title, rawText, apiKey = null, provider = null, options = {}) {
  const headers = sseHeaders(apiKey, provider, options.embeddingModel);

  const res = await fetch(`${API_BASE}/upload`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      title,
      rawText,
      chunkSize: options.chunkSize,
      chunkOverlap: options.chunkOverlap
    })
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error || 'Failed to index text note');
  }

  return res.json();
}

export async function deleteDocument(docId) {
  const res = await fetch(`${API_BASE}/documents/${docId}`, {
    method: 'DELETE'
  });
  if (!res.ok) throw new Error('Failed to delete document');
  return res.json();
}

export async function fetchDocChunks(docId) {
  const res = await fetch(`${API_BASE}/documents/${docId}/chunks`);
  if (!res.ok) throw new Error('Failed to fetch document chunks');
  return res.json();
}

export async function getStats() {
  const res = await fetch(`${API_BASE}/stats`);
  if (!res.ok) throw new Error('Failed to fetch stats');
  return res.json();
}

export async function verifyApiKey(apiKey, provider = 'gemini') {
  const res = await fetch(`${API_BASE}/settings/verify-key`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ apiKey, provider })
  });
  return res.json();
}

/**
 * Generic SSE stream reader. Shared by chat & SOP modes.
 */
async function readSseStream(response, { onCitations, onNotice, onChunk, onError, onDone }) {
  if (!response.ok) {
    const errJson = await response.json().catch(() => ({}));
    throw new Error(errJson.error || 'Failed to start streaming session');
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith('data: ')) continue;

      const dataStr = trimmed.slice(6);
      if (dataStr === '[DONE]') {
        if (onDone) onDone();
        return;
      }

      try {
        const parsed = JSON.parse(dataStr);
        if (parsed.type === 'CITATIONS') {
          if (onCitations) onCitations(parsed);
        } else if (parsed.type === 'NOTICE') {
          if (onNotice) onNotice(parsed.message || '');
        } else if (parsed.content) {
          if (onChunk) onChunk(parsed.content);
        } else if (parsed.error) {
          if (onError) onError(parsed.error);
        }
      } catch (e) {
        console.warn('[SSE Parse Warning]:', e);
      }
    }
  }

  if (onDone) onDone();
}

export async function streamChat({
  query,
  conversationHistory = [],
  apiKey = null,
  provider = 'gemini',
  chatModel = null,
  embeddingModel = null,
  topK = 4,
  signal = null,
  onCitations,
  onNotice,
  onChunk,
  onError,
  onDone
}) {
  try {
    const response = await fetch(`${API_BASE}/chat`, {
      method: 'POST',
      headers: sseHeaders(apiKey, provider, embeddingModel),
      body: JSON.stringify({
        query,
        conversationHistory,
        provider,
        chatModel,
        embeddingModel,
        topK
      }),
      signal
    });

    await readSseStream(response, { onCitations, onNotice, onChunk, onError, onDone });
  } catch (err) {
    if (err && (err.name === 'AbortError' || err.code === 'ABORT_ERR')) {
      if (onDone) onDone();
      return;
    }
    console.error('[Stream Chat API Error]:', err);
    if (onError) onError(err.message || 'Stream connection error');
  }
}

export async function streamSop({
  query,
  apiKey = null,
  provider = 'gemini',
  chatModel = null,
  embeddingModel = null,
  topK = 4,
  signal = null,
  onCitations,
  onNotice,
  onChunk,
  onError,
  onDone
}) {
  try {
    const response = await fetch(`${API_BASE}/sop`, {
      method: 'POST',
      headers: sseHeaders(apiKey, provider, embeddingModel),
      body: JSON.stringify({
        query,
        provider,
        chatModel,
        embeddingModel,
        topK
      }),
      signal
    });

    await readSseStream(response, { onCitations, onNotice, onChunk, onError, onDone });
  } catch (err) {
    if (err && (err.name === 'AbortError' || err.code === 'ABORT_ERR')) {
      if (onDone) onDone();
      return;
    }
    console.error('[Stream SOP API Error]:', err);
    if (onError) onError(err.message || 'Stream connection error');
  }
}
