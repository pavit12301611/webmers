import React, { useState, useEffect, useRef, useCallback } from 'react';
import Navbar from './components/Navbar';
import DocumentUploader from './components/Dashboard/DocumentUploader';
import DocumentList from './components/Dashboard/DocumentList';
import VectorStats from './components/Dashboard/VectorStats';
import SettingsModal from './components/Dashboard/SettingsModal';
import ChatWindow from './components/Chat/ChatWindow';
import { getDocuments, streamChat, streamSop } from './services/api';

const SESSIONS_KEY = 'pavit_sessions_v1';
const uid = () => `sess_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;

const GEMINI_CHAT_MODELS = [
  { value: 'gemini-flash-latest', label: 'gemini-flash-latest (Latest auto-updated)' },
  { value: 'gemini-2.5-flash', label: 'gemini-2.5-flash (Fast & next-gen)' },
  { value: 'gemini-2.5-pro', label: 'gemini-2.5-pro (High reasoning)' },
  { value: 'gemini-2.0-flash', label: 'gemini-2.0-flash (Ultra fast)' },
  { value: 'gemini-2.0-flash-lite', label: 'gemini-2.0-flash-lite (Budget)' }
];

const OPENAI_CHAT_MODELS = [
  { value: 'gpt-4o-mini', label: 'gpt-4o-mini (Fast & recommended)' },
  { value: 'gpt-4o', label: 'gpt-4o (High intelligence)' },
  { value: 'gpt-4.1-mini', label: 'gpt-4.1-mini (Fast, latest gen)' },
  { value: 'gpt-4.1', label: 'gpt-4.1 (Latest gen)' }
];

const GEMINI_EMBED_MODELS = [
  { value: 'gemini-embedding-001', label: 'gemini-embedding-001 (768 dim)' }
];

const OPENAI_EMBED_MODELS = [
  { value: 'text-embedding-3-small', label: 'text-embedding-3-small (1536 dim)' },
  { value: 'text-embedding-3-large', label: 'text-embedding-3-large (3072 dim)' },
  { value: 'text-embedding-ada-002', label: 'text-embedding-ada-002 (Legacy 1536 dim)' }
];

function loadSessions() {
  try {
    const raw = localStorage.getItem(SESSIONS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (_) {
    return [];
  }
}

export default function App() {
  const [activeTab, setActiveTab] = useState('chat');
  const [documents, setDocuments] = useState([]);
  const [stats, setStats] = useState(null);
  const [loadingDocs, setLoadingDocs] = useState(true);

  // --- Provider / keys (stored per-provider in localStorage) ---
  const [provider, setProvider] = useState(() => localStorage.getItem('pavit_provider') || 'gemini');
  const [apiKeys, setApiKeys] = useState(() => {
    try {
      return {
        gemini: localStorage.getItem('pavit_api_key_gemini') || localStorage.getItem('active_agent_api_key') || '',
        openai: localStorage.getItem('pavit_api_key_openai') || ''
      };
    } catch (_) { return { gemini: '', openai: '' }; }
  });
  const [chatModels, setChatModels] = useState(() => {
    try {
      return {
        gemini: localStorage.getItem('pavit_chat_model_gemini') || 'gemini-flash-latest',
        openai: localStorage.getItem('pavit_chat_model_openai') || 'gpt-4o-mini'
      };
    } catch (_) { return { gemini: 'gemini-flash-latest', openai: 'gpt-4o-mini' }; }
  });
  const [embeddingModels, setEmbeddingModels] = useState(() => {
    try {
      return {
        gemini: localStorage.getItem('pavit_embed_model_gemini') || 'gemini-embedding-001',
        openai: localStorage.getItem('pavit_embed_model_openai') || 'text-embedding-3-small'
      };
    } catch (_) { return { gemini: 'gemini-embedding-001', openai: 'text-embedding-3-small' }; }
  });
  const [topK, setTopK] = useState(() => Number(localStorage.getItem('pavit_top_k')) || 4);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // --- Chat sessions ---
  const [sessions, setSessions] = useState(loadSessions);
  const [activeSessionId, setActiveSessionId] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [mode, setMode] = useState('chat'); // 'chat' | 'sop'
  const abortRef = useRef(null);

  const activeSession = sessions.find(s => s.id === activeSessionId) || null;
  const messages = activeSession ? activeSession.messages : [];

  // Persist settings
  useEffect(() => { localStorage.setItem('pavit_provider', provider); }, [provider]);
  useEffect(() => { localStorage.setItem('pavit_api_key_gemini', apiKeys.gemini || ''); }, [apiKeys.gemini]);
  useEffect(() => { localStorage.setItem('pavit_api_key_openai', apiKeys.openai || ''); }, [apiKeys.openai]);
  useEffect(() => { localStorage.setItem('pavit_chat_model_gemini', chatModels.gemini); }, [chatModels.gemini]);
  useEffect(() => { localStorage.setItem('pavit_chat_model_openai', chatModels.openai); }, [chatModels.openai]);
  useEffect(() => { localStorage.setItem('pavit_embed_model_gemini', embeddingModels.gemini); }, [embeddingModels.gemini]);
  useEffect(() => { localStorage.setItem('pavit_embed_model_openai', embeddingModels.openai); }, [embeddingModels.openai]);
  useEffect(() => { localStorage.setItem('pavit_top_k', String(topK)); }, [topK]);

  // Persist sessions
  useEffect(() => {
    try { localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions)); } catch (_) { /* quota */ }
  }, [sessions]);

  // Ensure a session exists
  useEffect(() => {
    if (sessions.length === 0) {
      const fresh = { id: uid(), title: 'New Chat', messages: [], createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
      setSessions([fresh]);
      setActiveSessionId(fresh.id);
    } else if (!activeSessionId || !sessions.find(s => s.id === activeSessionId)) {
      setActiveSessionId(sessions[0].id);
    }
  }, [sessions, activeSessionId]);

  // Fetch documents + stats
  const fetchDocData = useCallback(async () => {
    setLoadingDocs(true);
    try {
      const data = await getDocuments();
      setDocuments(data.documents || []);
      setStats(data.stats || null);
      if (data.stats?.activeProvider && !localStorage.getItem('pavit_provider')) {
        setProvider(data.stats.activeProvider);
      }
    } catch (err) {
      console.error('[App] Failed to load documents:', err);
    } finally {
      setLoadingDocs(false);
    }
  }, []);

  useEffect(() => { fetchDocData(); }, [fetchDocData]);

  const patchActiveSession = useCallback((fn) => {
    setSessions(prev => prev.map(s => (s.id === activeSessionId ? { ...s, ...fn(s) } : s)));
  }, [activeSessionId]);

  const handleNewSession = useCallback(() => {
    const fresh = { id: uid(), title: 'New Chat', messages: [], createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    setSessions(prev => [fresh, ...prev]);
    setActiveSessionId(fresh.id);
  }, []);

  const handleDeleteSession = useCallback((id) => {
    setSessions(prev => {
      const next = prev.filter(s => s.id !== id);
      if (id === activeSessionId) {
        if (next.length > 0) setActiveSessionId(next[0].id);
        else {
          const fresh = { id: uid(), title: 'New Chat', messages: [], createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
          setSessions([fresh]);
          setActiveSessionId(fresh.id);
          return [fresh];
        }
      }
      return next;
    });
  }, [activeSessionId]);

  const handleRenameSession = useCallback((id, title) => {
    setSessions(prev => prev.map(s => (s.id === id ? { ...s, title: title || 'New Chat' } : s)));
  }, []);

  const handleSendMessage = useCallback(async (queryText, opts = {}) => {
    const sendMode = opts.mode || mode;
    const userMsg = { role: 'user', content: queryText, ts: new Date().toISOString() };

    // Ensure a session exists
    let sessionId = activeSessionId;
    if (!sessionId) {
      const fresh = { id: uid(), title: 'New Chat', messages: [], createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
      setSessions(prev => [fresh, ...prev]);
      setActiveSessionId(fresh.id);
      sessionId = fresh.id;
    }

    // Title from first message
    const title = queryText.length > 60 ? queryText.slice(0, 60) + '…' : queryText;

    setSessions(prev => prev.map(s => {
      if (s.id !== sessionId) return s;
      const isNew = s.messages.length === 0;
      return {
        ...s,
        title: isNew ? title : s.title,
        messages: [...s.messages, userMsg, { role: 'assistant', content: '', citations: null, generating: true }],
        updatedAt: new Date().toISOString()
      };
    }));

    setIsGenerating(true);
    const controller = new AbortController();
    abortRef.current = controller;

    const assistantIndexRef = { value: null };
    let accumulated = '';

    const setAssistantChunk = (chunkText) => {
      accumulated += chunkText;
      setSessions(prev => prev.map(s => {
        if (s.id !== sessionId) return s;
        const next = [...s.messages];
        if (assistantIndexRef.value == null) assistantIndexRef.value = next.length - 1;
        const idx = assistantIndexRef.value;
        if (next[idx]) {
          next[idx] = { ...next[idx], content: accumulated };
        }
        return { ...s, messages: next, updatedAt: new Date().toISOString() };
      }));
    };

    const setAssistantCitations = (payload) => {
      setSessions(prev => prev.map(s => {
        if (s.id !== sessionId) return s;
        const next = [...s.messages];
        const idx = assistantIndexRef.value == null ? next.length - 1 : assistantIndexRef.value;
        if (next[idx]) {
          next[idx] = { ...next[idx], citations: payload.citations || [], retrievalMeta: payload };
        }
        return { ...s, messages: next };
      }));
    };

    const finishAssistant = (content) => {
      setSessions(prev => prev.map(s => {
        if (s.id !== sessionId) return s;
        const next = [...s.messages];
        const idx = assistantIndexRef.value == null ? next.length - 1 : assistantIndexRef.value;
        if (next[idx]) {
          next[idx] = { ...next[idx], content: content ?? next[idx].content, generating: false };
        }
        return { ...s, messages: next, updatedAt: new Date().toISOString() };
      }));
      setIsGenerating(false);
      abortRef.current = null;
    };

    // History = all previous turns (backend appends the current query itself)
    const historyForApi = activeSession ? activeSession.messages : [];

    const common = {
      apiKey: apiKeys[provider] || null,
      provider,
      chatModel: chatModels[provider] || null,
      embeddingModel: embeddingModels[provider] || null,
      topK,
      signal: controller.signal,
      onCitations: setAssistantCitations,
      onNotice: (msg) => setAssistantChunk(`> ℹ️ ${msg}\n\n`),
      onChunk: setAssistantChunk,
      onError: (errMessage) => {
        finishAssistant(`⚠️ **Error generating response:** ${errMessage}`);
      },
      onDone: () => finishAssistant(null)
    };

    if (sendMode === 'sop') {
      await streamSop({ ...common, query: queryText });
    } else {
      await streamChat({ ...common, query: queryText, conversationHistory: historyForApi });
    }
  }, [activeSessionId, activeSession, apiKeys, provider, chatModels, embeddingModels, topK, mode]);

  const handleStop = useCallback(() => {
    if (abortRef.current) {
      abortRef.current.abort();
    }
    setSessions(prev => prev.map(s => {
      if (s.id !== activeSessionId) return s;
      const next = [...s.messages];
      const last = next[next.length - 1];
      if (last && last.generating) {
        next[next.length - 1] = { ...last, generating: false, content: last.content || '*(generation stopped)*' };
      }
      return { ...s, messages: next, updatedAt: new Date().toISOString() };
    }));
    setIsGenerating(false);
    abortRef.current = null;
  }, [activeSessionId]);

  const handleClearChat = useCallback(() => {
    patchActiveSession(s => ({ messages: [], title: 'New Chat' }));
  }, [patchActiveSession]);

  const handleRegenerate = useCallback((assistantIdx) => {
    if (isGenerating || !activeSession) return;
    const msgs = activeSession.messages;
    const target = msgs[assistantIdx];
    if (!target || target.role !== 'assistant') return;

    // Find the user message that precedes this assistant message
    let userIdx = assistantIdx - 1;
    while (userIdx >= 0 && msgs[userIdx].role !== 'user') userIdx--;
    if (userIdx < 0) return;

    const queryText = msgs[userIdx].content;
    const sessionId = activeSession.id;

    // Remove the assistant message and anything after it
    setSessions(prev => prev.map(s => {
      if (s.id !== sessionId) return s;
      return { ...s, messages: s.messages.slice(0, assistantIdx), updatedAt: new Date().toISOString() };
    }));

    // Re-send
    setIsGenerating(true);
    const controller = new AbortController();
    abortRef.current = controller;

    setSessions(prev => prev.map(s => {
      if (s.id !== sessionId) return s;
      return {
        ...s,
        messages: [...s.messages, { role: 'assistant', content: '', citations: null, generating: true }],
        updatedAt: new Date().toISOString()
      };
    }));

    const ref = { value: null };
    let accumulated = '';
    const setChunk = (t) => {
      accumulated += t;
      setSessions(prev => prev.map(s => {
        if (s.id !== sessionId) return s;
        const next = [...s.messages];
        if (ref.value == null) ref.value = next.length - 1;
        if (next[ref.value]) next[ref.value] = { ...next[ref.value], content: accumulated };
        return { ...s, messages: next };
      }));
    };
    const setCites = (payload) => {
      setSessions(prev => prev.map(s => {
        if (s.id !== sessionId) return s;
        const next = [...s.messages];
        const idx = ref.value == null ? next.length - 1 : ref.value;
        if (next[idx]) next[idx] = { ...next[idx], citations: payload.citations || [], retrievalMeta: payload };
        return { ...s, messages: next };
      }));
    };
    const finish = (content) => {
      setSessions(prev => prev.map(s => {
        if (s.id !== sessionId) return s;
        const next = [...s.messages];
        const idx = ref.value == null ? next.length - 1 : ref.value;
        if (next[idx]) next[idx] = { ...next[idx], content: content ?? next[idx].content, generating: false };
        return { ...s, messages: next, updatedAt: new Date().toISOString() };
      }));
      setIsGenerating(false);
      abortRef.current = null;
    };

    const historyForApi = msgs.slice(0, userIdx);

    const common = {
      apiKey: apiKeys[provider] || null,
      provider,
      chatModel: chatModels[provider] || null,
      embeddingModel: embeddingModels[provider] || null,
      topK,
      signal: controller.signal,
      onCitations: setCites,
      onNotice: (msg) => setChunk(`> ℹ️ ${msg}\n\n`),
      onChunk: (t) => setChunk(t),
      onError: (errMessage) => finish(`⚠️ **Error generating response:** ${errMessage}`),
      onDone: () => finish(null)
    };

    if (mode === 'sop') {
      streamSop({ ...common, query: queryText });
    } else {
      streamChat({ ...common, query: queryText, conversationHistory: historyForApi });
    }
  }, [activeSession, isGenerating, apiKeys, provider, chatModels, embeddingModels, topK, mode]);

  const apiKey = apiKeys[provider] || '';

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        stats={stats}
        apiKey={apiKey}
        provider={provider}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      <main style={{ flex: 1 }}>
        {activeTab === 'chat' ? (
          <ChatWindow
            sessions={sessions}
            activeSessionId={activeSessionId}
            onSelectSession={setActiveSessionId}
            onNewSession={handleNewSession}
            onDeleteSession={handleDeleteSession}
            onRenameSession={handleRenameSession}
            messages={messages}
            isGenerating={isGenerating}
            onSendMessage={handleSendMessage}
            onStop={handleStop}
            onRegenerate={handleRegenerate}
            onClearChat={handleClearChat}
            stats={stats}
            mode={mode}
            setMode={setMode}
            onSwitchToDashboard={() => setActiveTab('dashboard')}
          />
        ) : (
          <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '1.75rem 1.5rem' }} className="animate-fade-in">
            <VectorStats stats={stats} />
            <DocumentUploader
              apiKey={apiKeys[provider] || null}
              provider={provider}
              embeddingModel={embeddingModels[provider] || null}
              onUploadSuccess={fetchDocData}
            />
            <DocumentList
              documents={documents}
              onRefresh={fetchDocData}
              onDeleteSuccess={fetchDocData}
            />
          </div>
        )}
      </main>

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        provider={provider}
        setProvider={setProvider}
        apiKey={apiKey}
        setApiKey={(val) => setApiKeys(prev => ({ ...prev, [provider]: val }))}
        chatModel={chatModels[provider] || ''}
        setChatModel={(val) => setChatModels(prev => ({ ...prev, [provider]: val }))}
        embeddingModel={embeddingModels[provider] || ''}
        setEmbeddingModel={(val) => setEmbeddingModels(prev => ({ ...prev, [provider]: val }))}
        topK={topK}
        setTopK={setTopK}
        chatModelOptions={provider === 'gemini' ? GEMINI_CHAT_MODELS : OPENAI_CHAT_MODELS}
        embeddingModelOptions={provider === 'gemini' ? GEMINI_EMBED_MODELS : OPENAI_EMBED_MODELS}
        stats={stats}
      />
    </div>
  );
}
