import React, { useState, useRef, useEffect } from 'react';
import { Zap, MessageSquare, UploadCloud, Settings, Database, ChevronDown, User, ShieldCheck, Bot } from 'lucide-react';

export default function Navbar({ activeTab, setActiveTab, stats, apiKey, provider, onOpenSettings }) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);

  const activeAgentName = provider === 'gemini' ? 'Google Gemini' : 'OpenAI';

  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0.85rem 2rem',
      background: 'rgba(16, 20, 18, 0.95)',
      backdropFilter: 'blur(16px)',
      borderBottom: '1px solid var(--border-color)',
      position: 'sticky',
      top: 0,
      zIndex: 50
    }}>
      {/* Brand Logo & Title */}
      <div
        onClick={() => setActiveTab('chat')}
        style={{ display: 'flex', alignItems: 'center', gap: '0.85rem', cursor: 'pointer' }}
      >
        <div style={{
          width: '42px',
          height: '42px',
          borderRadius: '50%',
          background: 'var(--lime-primary)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 0 18px var(--lime-glow)'
        }}>
          <Zap size={22} color="var(--lime-text-dark)" />
        </div>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <h1 style={{ fontSize: '1.3rem', fontWeight: '800', color: '#ffffff', letterSpacing: '0.02em' }}>
              PAVIT <span style={{ color: 'var(--lime-primary)' }}>AI</span>
            </h1>
            <span className="badge badge-lime" style={{ fontSize: '0.68rem' }}>
              {activeAgentName}
            </span>
          </div>
          <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>AI Document Intelligence &amp; Q&A · Built by PAVIT</p>
        </div>
      </div>

      {/* Right Navigation & User Dropdown */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
        {/* Vector Count Badge */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.4rem',
          fontSize: '0.78rem',
          color: 'var(--lime-primary)',
          background: 'rgba(136, 231, 20, 0.08)',
          padding: '0.4rem 0.85rem',
          borderRadius: '999px',
          border: '1px solid rgba(136, 231, 20, 0.25)'
        }}>
          <Database size={14} color="var(--lime-primary)" />
          <span>{stats?.totalVectors || 0} Vectors</span>
        </div>

        {/* Profile Dropdown */}
        <div ref={dropdownRef} style={{ position: 'relative' }}>
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.65rem',
              background: dropdownOpen ? 'rgba(136, 231, 20, 0.15)' : 'var(--bg-card)',
              border: `1px solid ${dropdownOpen ? 'var(--lime-primary)' : 'var(--border-color)'}`,
              padding: '0.35rem 0.85rem 0.35rem 0.45rem',
              borderRadius: '999px',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              boxShadow: dropdownOpen ? '0 0 15px var(--lime-glow)' : 'none'
            }}
          >
            <div style={{
              width: '32px',
              height: '32px',
              borderRadius: '50%',
              background: 'var(--lime-primary)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: '800',
              fontSize: '0.8rem',
              color: 'var(--lime-text-dark)'
            }}>
              <User size={16} />
            </div>

            <span style={{ fontSize: '0.85rem', fontWeight: '700', color: '#ffffff' }}>PAVIT</span>
            <ChevronDown size={14} color="var(--text-muted)" style={{ transition: 'transform 0.2s', transform: dropdownOpen ? 'rotate(180deg)' : 'none' }} />
          </button>

          {/* User Dropdown Menu */}
          {dropdownOpen && (
            <div className="animate-fade-in" style={{
              position: 'absolute',
              top: 'calc(100% + 0.6rem)',
              right: 0,
              width: '280px',
              background: 'var(--bg-card)',
              backdropFilter: 'blur(20px)',
              border: '1px solid var(--lime-primary)',
              borderRadius: 'var(--radius-lg)',
              boxShadow: '0 12px 40px rgba(0, 0, 0, 0.8), 0 0 20px var(--lime-glow)',
              padding: '0.6rem',
              zIndex: 100
            }}>
              <div style={{ padding: '0.6rem 0.75rem', borderBottom: '1px solid var(--border-color)', marginBottom: '0.4rem' }}>
                <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: '700' }}>
                  PAVIT AI
                </span>
                <p style={{ fontSize: '0.88rem', fontWeight: '800', color: 'var(--lime-primary)', marginTop: '0.1rem' }}>
                  Knowledge Base Manager
                </p>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
                <button
                  onClick={() => { setActiveTab('chat'); setDropdownOpen(false); }}
                  style={{
                    display: 'flex', alignItems: 'center', gap: '0.65rem', width: '100%', padding: '0.65rem 0.75rem',
                    borderRadius: '999px', border: 'none', textAlign: 'left', cursor: 'pointer', transition: 'all 0.15s ease',
                    background: activeTab === 'chat' ? 'var(--lime-primary)' : 'transparent',
                    color: activeTab === 'chat' ? 'var(--lime-text-dark)' : 'var(--text-main)',
                    fontSize: '0.85rem', fontWeight: '700'
                  }}
                >
                  <MessageSquare size={16} />
                  AI Chatbot Assistant
                </button>

                <button
                  onClick={() => { setActiveTab('dashboard'); setDropdownOpen(false); }}
                  style={{
                    display: 'flex', alignItems: 'center', gap: '0.65rem', width: '100%', padding: '0.65rem 0.75rem',
                    borderRadius: '999px', border: 'none', textAlign: 'left', cursor: 'pointer', transition: 'all 0.15s ease',
                    background: activeTab === 'dashboard' ? 'var(--lime-primary)' : 'transparent',
                    color: activeTab === 'dashboard' ? 'var(--lime-text-dark)' : 'var(--text-main)',
                    fontSize: '0.85rem', fontWeight: '700'
                  }}
                >
                  <UploadCloud size={16} />
                  Document Uploader Dashboard
                </button>

                <button
                  onClick={() => { onOpenSettings(); setDropdownOpen(false); }}
                  style={{
                    display: 'flex', alignItems: 'center', gap: '0.65rem', width: '100%', padding: '0.65rem 0.75rem',
                    borderRadius: '999px', border: 'none', background: 'transparent', color: 'var(--text-main)',
                    fontSize: '0.85rem', fontWeight: '600', textAlign: 'left', cursor: 'pointer', transition: 'all 0.15s ease'
                  }}
                >
                  <Settings size={16} />
                  AI Agent &amp; Key Settings
                </button>
              </div>

              <div style={{
                marginTop: '0.5rem', padding: '0.5rem 0.75rem', borderTop: '1px solid var(--border-color)',
                fontSize: '0.72rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', justifyContent: 'space-between'
              }}>
                <span>Agent: {provider.toUpperCase()} {apiKey ? '· Key set' : '· No key'}</span>
                <ShieldCheck size={14} color="var(--lime-primary)" />
              </div>

              <div style={{ marginTop: '0.3rem', padding: '0.5rem 0.75rem', borderTop: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                <Bot size={13} color="var(--text-dim)" />
                <span style={{ fontSize: '0.7rem', color: 'var(--text-dim)' }}>Built by PAVIT · v2.0</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
