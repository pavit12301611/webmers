import React from 'react';
import { Database, FileText, Cpu, HardDrive, AlertTriangle, Zap } from 'lucide-react';

function formatBytes(bytes) {
  if (!bytes || bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

export default function VectorStats({ stats }) {
  const hasKey = stats?.providerInfo
    ? (stats.providerInfo.isGemini ? stats.providerInfo.hasGeminiApiKey : stats.providerInfo.hasOpenAiApiKey)
    : false;

  return (
    <div>
      {stats?.mixedDimensions && (
        <div style={{
          marginBottom: '1rem', padding: '0.7rem 1rem', borderRadius: 'var(--radius-md)', fontSize: '0.8rem',
          background: 'rgba(245, 158, 11, 0.12)', border: '1px solid rgba(245, 158, 11, 0.35)', color: '#fbbf24',
          display: 'flex', alignItems: 'center', gap: '0.5rem'
        }}>
          <AlertTriangle size={16} />
          <span>
            Mixed embedding dimensions detected in your store ({stats.dimensionsInUse?.join(', ') || '?'}). Chunks embedded with a different model than your active provider may not be searchable. Re-upload those files or clear the store.
          </span>
        </div>
      )}

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: '1.25rem',
        marginBottom: '1.5rem'
      }}>
        {/* Stat Card 1 */}
        <div className="glass-panel" style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <div style={{
            width: '46px', height: '46px', borderRadius: 'var(--radius-md)',
            background: 'rgba(99, 102, 241, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center',
            border: '1px solid rgba(99, 102, 241, 0.3)'
          }}>
            <FileText size={22} color="#818cf8" />
          </div>
          <div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: '600' }}>
              Active Files
            </span>
            <h3 style={{ fontSize: '1.4rem', fontWeight: '800', color: '#fff' }}>
              {stats?.totalDocuments || 0}
            </h3>
          </div>
        </div>

        {/* Stat Card 2 */}
        <div className="glass-panel" style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <div style={{
            width: '46px', height: '46px', borderRadius: 'var(--radius-md)',
            background: 'rgba(6, 182, 212, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center',
            border: '1px solid rgba(6, 182, 212, 0.3)'
          }}>
            <Database size={22} color="#22d3ee" />
          </div>
          <div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: '600' }}>
              Vector Chunks
            </span>
            <h3 style={{ fontSize: '1.4rem', fontWeight: '800', color: '#fff' }}>
              {stats?.totalVectors || 0}
            </h3>
          </div>
        </div>

        {/* Stat Card 3 */}
        <div className="glass-panel" style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <div style={{
            width: '46px', height: '46px', borderRadius: 'var(--radius-md)',
            background: 'rgba(16, 185, 129, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center',
            border: '1px solid rgba(16, 185, 129, 0.3)'
          }}>
            <Cpu size={22} color="#34d399" />
          </div>
          <div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: '600' }}>
              Embedding Model
            </span>
            <h3 style={{ fontSize: '0.88rem', fontWeight: '700', color: '#34d399', wordBreak: 'break-all' }}>
              {stats?.embeddingModel || '—'}
            </h3>
            <span style={{ fontSize: '0.68rem', color: 'var(--text-dim)' }}>
              {stats?.vectorDimension ? `${stats.vectorDimension} dim` : ''}
            </span>
          </div>
        </div>

        {/* Stat Card 4 */}
        <div className="glass-panel" style={{ padding: '1.25rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <div style={{
            width: '46px', height: '46px', borderRadius: 'var(--radius-md)',
            background: 'rgba(168, 85, 247, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center',
            border: '1px solid rgba(168, 85, 247, 0.3)'
          }}>
            <HardDrive size={22} color="#c084fc" />
          </div>
          <div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: '600' }}>
              Vector Storage
            </span>
            <h3 style={{ fontSize: '1rem', fontWeight: '700', color: '#c084fc' }}>
              {formatBytes(stats?.storageSizeBytes)}
            </h3>
            <span style={{ fontSize: '0.68rem', color: 'var(--text-dim)' }}>Embedded disk DB</span>
          </div>
        </div>
      </div>

      {/* Provider status strip */}
      <div className="glass-panel" style={{ padding: '0.9rem 1.25rem', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <Zap size={16} color="var(--lime-primary)" />
          <strong style={{ fontSize: '0.85rem', color: '#fff' }}>
            Active Agent: {(stats?.activeProvider || '—').toUpperCase()}
          </strong>
        </div>
        <span className={`badge ${hasKey ? 'badge-lime' : 'badge-coral'}`}>
          {hasKey ? 'API key configured' : 'No API key — local fallback embeddings'}
        </span>
        {stats?.providerInfo && (
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
            Chat: {stats.providerInfo.isGemini ? stats.providerInfo.geminiModel : stats.providerInfo.openaiModel}
            {' · '}
            Embedding: {stats.providerInfo.isGemini ? stats.providerInfo.geminiEmbeddingModel : stats.providerInfo.openaiEmbeddingModel}
          </span>
        )}
        {stats?.mixedDimensions && (
          <span style={{ fontSize: '0.75rem', color: '#fbbf24', marginLeft: 'auto' }}>
            ⚠ {stats.dimensionsInUse?.join(', ')} dims mixed
          </span>
        )}
      </div>
    </div>
  );
}
