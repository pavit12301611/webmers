import React, { useState } from 'react';
import { Settings, Key, Cpu, CheckCircle2, AlertCircle, Loader2, X, Sliders, Sparkles, Layers } from 'lucide-react';
import { verifyApiKey } from '../../services/api';

export default function SettingsModal({
  isOpen,
  onClose,
  provider,
  setProvider,
  apiKey,
  setApiKey,
  chatModel,
  setChatModel,
  embeddingModel,
  setEmbeddingModel,
  topK,
  setTopK,
  chatModelOptions,
  embeddingModelOptions,
  stats
}) {
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);

  if (!isOpen) return null;

  const handleTestKey = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await verifyApiKey(apiKey, provider);
      setTestResult(res);
    } catch (err) {
      setTestResult({ valid: false, error: err.message });
    } finally {
      setTesting(false);
    }
  };

  const switchProvider = (p) => {
    setProvider(p);
    setTestResult(null);
  };

  return (
    <div style={{
      position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
      background: 'rgba(0, 0, 0, 0.75)', backdropFilter: 'blur(8px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: '1.5rem'
    }}>
      <div className="glass-panel animate-fade-in" style={{
        width: '100%', maxWidth: '580px', display: 'flex', flexDirection: 'column', overflow: 'hidden'
      }}>
        {/* Modal Header */}
        <div style={{
          padding: '1.25rem 1.5rem', borderBottom: '1px solid var(--border-color)',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <Settings size={20} color="#818cf8" />
            <h3 style={{ fontSize: '1.1rem', fontWeight: '700', color: '#fff' }}>AI Agent &amp; RAG Settings</h3>
          </div>
          <button onClick={onClose} className="btn-secondary" style={{ padding: '0.35rem' }}>
            <X size={18} />
          </button>
        </div>

        {/* Modal Body */}
        <div style={{ padding: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1.15rem', maxHeight: '70vh', overflowY: 'auto' }}>
          {/* Agent Selection Switch */}
          <div>
            <label style={{ fontSize: '0.85rem', fontWeight: '600', color: 'var(--text-main)', display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.5rem' }}>
              <Cpu size={16} color="#06b6d4" /> Choose Active AI Agent Provider
            </label>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
              <button
                type="button"
                onClick={() => switchProvider('gemini')}
                style={{
                  padding: '0.75rem', borderRadius: 'var(--radius-md)',
                  border: `2px solid ${provider === 'gemini' ? '#06b6d4' : 'var(--border-color)'}`,
                  background: provider === 'gemini' ? 'rgba(6, 182, 212, 0.15)' : 'rgba(0,0,0,0.2)',
                  color: provider === 'gemini' ? '#22d3ee' : 'var(--text-muted)',
                  cursor: 'pointer', fontWeight: '700', fontSize: '0.85rem',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
                  transition: 'all 0.2s ease'
                }}
              >
                <Sparkles size={16} /> Google Gemini Agent
              </button>

              <button
                type="button"
                onClick={() => switchProvider('openai')}
                style={{
                  padding: '0.75rem', borderRadius: 'var(--radius-md)',
                  border: `2px solid ${provider === 'openai' ? '#818cf8' : 'var(--border-color)'}`,
                  background: provider === 'openai' ? 'rgba(99, 102, 241, 0.15)' : 'rgba(0,0,0,0.2)',
                  color: provider === 'openai' ? '#818cf8' : 'var(--text-muted)',
                  cursor: 'pointer', fontWeight: '700', fontSize: '0.85rem',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.4rem',
                  transition: 'all 0.2s ease'
                }}
              >
                <Cpu size={16} /> OpenAI Agent
              </button>
            </div>
            <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '0.4rem' }}>
              Default agent can be locked in your <code>.env</code> file via <code>LLM_PROVIDER=gemini</code> or <code>LLM_PROVIDER=openai</code>. Each provider keeps its own API key &amp; model stored locally in your browser.
            </p>
          </div>

          <hr style={{ borderColor: 'var(--border-color)', opacity: 0.5 }} />

          {/* API Key */}
          <div>
            <label style={{ fontSize: '0.85rem', fontWeight: '600', color: 'var(--text-main)', display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.4rem' }}>
              <Key size={16} color="#fbbf24" /> {provider === 'gemini' ? 'Google Gemini API Key' : 'OpenAI API Key'}
            </label>
            <input
              type="password"
              placeholder={provider === 'gemini' ? 'AIzaSy...' : 'sk-...'}
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              style={{
                width: '100%', padding: '0.65rem 0.85rem', background: 'var(--bg-input)',
                border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)',
                color: '#fff', fontFamily: 'var(--font-mono)', fontSize: '0.85rem', outline: 'none'
              }}
            />
            <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '0.3rem' }}>
              Stored locally in browser. Leave empty to use the server <code>.env</code> key ({provider === 'gemini' ? 'GEMINI_API_KEY' : 'OPENAI_API_KEY'}).
            </p>
          </div>

          {/* Test Key Button */}
          <div>
            <button onClick={handleTestKey} className="btn-secondary" style={{ width: '100%', justifyContent: 'center' }} disabled={testing}>
              {testing ? <Loader2 size={16} style={{ animation: 'spin 1s linear infinite' }} /> : `Verify ${provider === 'gemini' ? 'Gemini' : 'OpenAI'} Connection`}
            </button>

            {testResult && (
              <div style={{
                marginTop: '0.75rem', padding: '0.65rem 0.85rem', borderRadius: 'var(--radius-md)', fontSize: '0.8rem',
                background: testResult.valid ? 'rgba(16, 185, 129, 0.15)' : 'rgba(239, 68, 68, 0.15)',
                border: `1px solid ${testResult.valid ? 'rgba(16, 185, 129, 0.3)' : 'rgba(239, 68, 68, 0.3)'}`,
                color: testResult.valid ? '#34d399' : '#f87171',
                display: 'flex', alignItems: 'center', gap: '0.4rem'
              }}>
                {testResult.valid ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />}
                <span>{testResult.message || testResult.error}</span>
              </div>
            )}
          </div>

          {/* Chat Model Selection */}
          <div>
            <label style={{ fontSize: '0.85rem', fontWeight: '600', color: 'var(--text-main)', display: 'block', marginBottom: '0.4rem' }}>
              Chat Model
            </label>
            <select
              value={chatModel}
              onChange={(e) => setChatModel(e.target.value)}
              style={{
                width: '100%', padding: '0.65rem 0.85rem', background: 'var(--bg-input)',
                border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)',
                color: '#fff', fontFamily: 'var(--font-body)', fontSize: '0.85rem', outline: 'none'
              }}
            >
              {(chatModelOptions || []).map(opt => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
          </div>

          {/* Embedding Model Selection */}
          <div>
            <label style={{ fontSize: '0.85rem', fontWeight: '600', color: 'var(--text-main)', display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.4rem' }}>
              <Layers size={16} color="#34d399" /> Embedding Model (for vector search)
            </label>
            <select
              value={embeddingModel}
              onChange={(e) => setEmbeddingModel(e.target.value)}
              style={{
                width: '100%', padding: '0.65rem 0.85rem', background: 'var(--bg-input)',
                border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)',
                color: '#fff', fontFamily: 'var(--font-body)', fontSize: '0.85rem', outline: 'none'
              }}
            >
              {(embeddingModelOptions || []).map(opt => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
            <p style={{ fontSize: '0.7rem', color: 'var(--text-dim)', marginTop: '0.3rem' }}>
              Changing this affects new uploads only. Existing chunks keep their original embedding; switching providers may make old chunks unsearchable (the dashboard will warn you).
            </p>
          </div>

          {/* Top-K Retrieval Matches */}
          <div>
            <label style={{ fontSize: '0.85rem', fontWeight: '600', color: 'var(--text-main)', display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.4rem' }}>
              <Sliders size={16} color="#06b6d4" /> Top-K Context Matches: <strong style={{ color: '#fff' }}>{topK}</strong>
            </label>
            <input
              type="range"
              min="1"
              max="10"
              value={topK}
              onChange={(e) => setTopK(Number(e.target.value))}
              style={{ width: '100%', accentColor: 'var(--primary)' }}
            />
          </div>

          {/* Server status */}
          {stats?.providerInfo && (
            <div style={{ background: 'rgba(0,0,0,0.25)', padding: '0.7rem 0.9rem', borderRadius: 'var(--radius-md)', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
              Server: {stats.providerInfo.provider.toUpperCase()} · Chat {stats.providerInfo.isGemini ? stats.providerInfo.geminiModel : stats.providerInfo.openaiModel}
              {' · '}Has {stats.providerInfo.isGemini ? 'Gemini' : 'OpenAI'} key: <strong style={{ color: stats.providerInfo.isGemini ? (stats.providerInfo.hasGeminiApiKey ? '#34d399' : '#f87171') : (stats.providerInfo.hasOpenAiApiKey ? '#34d399' : '#f87171') }}>
                {stats.providerInfo.isGemini ? (stats.providerInfo.hasGeminiApiKey ? 'yes' : 'no') : (stats.providerInfo.hasOpenAiApiKey ? 'yes' : 'no')}
              </strong>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div style={{
          padding: '1.25rem 1.5rem', borderTop: '1px solid var(--border-color)',
          display: 'flex', justifyContent: 'flex-end'
        }}>
          <button onClick={onClose} className="btn-primary">
            Save &amp; Apply Agent
          </button>
        </div>
      </div>
    </div>
  );
}
