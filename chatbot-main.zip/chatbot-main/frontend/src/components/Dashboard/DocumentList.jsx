import React, { useState } from 'react';
import { FileText, Trash2, Layers, Calendar, HardDrive, Eye, RefreshCw, AlertTriangle, X, ListTree, Loader2 } from 'lucide-react';
import { deleteDocument, fetchDocChunks } from '../../services/api';

export default function DocumentList({ documents, onRefresh, onDeleteSuccess }) {
  const [selectedDoc, setSelectedDoc] = useState(null);
  const [chunks, setChunks] = useState(null);
  const [loadingChunks, setLoadingChunks] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async (docId) => {
    if (!window.confirm('Are you sure you want to remove this document and all its vector embeddings?')) return;
    setIsDeleting(true);
    try {
      await deleteDocument(docId);
      if (onDeleteSuccess) onDeleteSuccess();
    } catch (err) {
      alert('Failed to delete document: ' + err.message);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleClearAll = async () => {
    if (!window.confirm('WARNING: Are you sure you want to flush all documents and vectors from the Vector Database?')) return;
    setIsDeleting(true);
    try {
      await deleteDocument('all');
      if (onDeleteSuccess) onDeleteSuccess();
    } catch (err) {
      alert('Failed to clear database: ' + err.message);
    } finally {
      setIsDeleting(false);
    }
  };

  const openInspector = async (doc) => {
    setSelectedDoc(doc);
    setChunks(null);
    setLoadingChunks(true);
    try {
      const data = await fetchDocChunks(doc.id);
      setChunks(data.chunks || []);
    } catch (err) {
      setChunks([]);
      console.warn('Failed to load chunks:', err.message);
    } finally {
      setLoadingChunks(false);
    }
  };

  const formatFileSize = (bytes) => {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  return (
    <div className="glass-panel" style={{ padding: '1.5rem', marginTop: '1.5rem' }}>
      {/* Table Header & Controls */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem', flexWrap: 'wrap', gap: '0.75rem' }}>
        <div>
          <h2 style={{ fontSize: '1.15rem', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <FileText size={20} color="#06b6d4" />
            Knowledge Base Documents
          </h2>
          <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            Manage active knowledge sources indexed in the vector store ({documents?.length || 0} active files).
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <button onClick={onRefresh} className="btn-secondary" style={{ padding: '0.35rem 0.75rem', fontSize: '0.8rem' }}>
            <RefreshCw size={14} /> Refresh
          </button>
          {documents && documents.length > 0 && (
            <button onClick={handleClearAll} className="btn-danger" disabled={isDeleting}>
              <Trash2 size={14} /> Clear All Vectors
            </button>
          )}
        </div>
      </div>

      {/* Documents Table */}
      {!documents || documents.length === 0 ? (
        <div style={{
          textAlign: 'center', padding: '3rem 1rem', background: 'rgba(0,0,0,0.15)',
          borderRadius: 'var(--radius-md)', border: '1px dashed var(--border-color)'
        }}>
          <FileText size={40} color="var(--text-dim)" style={{ marginBottom: '0.5rem' }} />
          <h4 style={{ fontSize: '0.95rem', color: 'var(--text-muted)' }}>No Documents Uploaded Yet</h4>
          <p style={{ fontSize: '0.78rem', color: 'var(--text-dim)', marginTop: '0.2rem' }}>
            Upload files or text notes using the uploader above to populate your vector database.
          </p>
        </div>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.85rem' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)', fontSize: '0.78rem' }}>
                <th style={{ padding: '0.75rem 1rem' }}>Document Name</th>
                <th style={{ padding: '0.75rem 1rem' }}>Type</th>
                <th style={{ padding: '0.75rem 1rem' }}>Size</th>
                <th style={{ padding: '0.75rem 1rem' }}>Vector Chunks</th>
                <th style={{ padding: '0.75rem 1rem' }}>Embedding</th>
                <th style={{ padding: '0.75rem 1rem' }}>Indexed Date</th>
                <th style={{ padding: '0.75rem 1rem', textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {documents.map((doc) => (
                <tr
                  key={doc.id}
                  style={{ borderBottom: '1px solid rgba(255,255,255,0.04)', transition: 'background 0.15s ease' }}
                  onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(255,255,255,0.03)'}
                  onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                >
                  <td style={{ padding: '0.85rem 1rem', fontWeight: '600', color: '#fff' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <FileText size={16} color="#818cf8" />
                      <span style={{ maxWidth: '220px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {doc.originalName}
                      </span>
                    </div>
                  </td>
                  <td style={{ padding: '0.85rem 1rem' }}>
                    <span className="badge badge-cyan">{doc.fileType}</span>
                  </td>
                  <td style={{ padding: '0.85rem 1rem', color: 'var(--text-muted)' }}>
                    {formatFileSize(doc.size)}
                  </td>
                  <td style={{ padding: '0.85rem 1rem' }}>
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.3rem', color: '#34d399', fontWeight: '600' }}>
                      <Layers size={14} /> {doc.chunkCount} chunks
                    </span>
                  </td>
                  <td style={{ padding: '0.85rem 1rem', color: 'var(--text-muted)', fontSize: '0.75rem', maxWidth: '150px' }}>
                    <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'inline-block', maxWidth: '140px' }}>
                      {doc.embeddingModel || '—'}
                    </span>
                  </td>
                  <td style={{ padding: '0.85rem 1rem', color: 'var(--text-muted)' }}>
                    {new Date(doc.createdAt).toLocaleDateString()}
                  </td>
                  <td style={{ padding: '0.85rem 1rem', textAlign: 'right' }}>
                    <div style={{ display: 'inline-flex', gap: '0.4rem' }}>
                      <button
                        onClick={() => openInspector(doc)}
                        className="btn-secondary"
                        style={{ padding: '0.35rem 0.55rem', fontSize: '0.75rem' }}
                        title="View Details & Chunks"
                      >
                        <Eye size={14} /> View
                      </button>
                      <button
                        onClick={() => handleDelete(doc.id)}
                        className="btn-danger"
                        style={{ padding: '0.35rem 0.55rem' }}
                        title="Delete Document"
                        disabled={isDeleting}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Document Inspector Modal */}
      {selectedDoc && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          background: 'rgba(0, 0, 0, 0.75)', backdropFilter: 'blur(8px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100, padding: '1.5rem'
        }}>
          <div className="glass-panel animate-fade-in" style={{
            width: '100%', maxWidth: '720px', maxHeight: '85vh',
            display: 'flex', flexDirection: 'column', overflow: 'hidden'
          }}>
            <div style={{
              padding: '1.25rem', borderBottom: '1px solid var(--border-color)',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between'
            }}>
              <div style={{ minWidth: 0 }}>
                <h3 style={{ fontSize: '1.1rem', fontWeight: '700', color: '#fff', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '520px' }}>
                  {selectedDoc.originalName}
                </h3>
                <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Doc ID: {selectedDoc.id}</p>
              </div>
              <button onClick={() => setSelectedDoc(null)} className="btn-secondary" style={{ padding: '0.35rem' }}>
                <X size={18} />
              </button>
            </div>

            <div style={{ padding: '1.25rem', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: '0.75rem' }}>
                <div style={{ background: 'rgba(0,0,0,0.3)', padding: '0.75rem', borderRadius: 'var(--radius-md)' }}>
                  <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block' }}>File Format</span>
                  <strong style={{ fontSize: '0.9rem', color: '#22d3ee' }}>{selectedDoc.fileType}</strong>
                </div>
                <div style={{ background: 'rgba(0,0,0,0.3)', padding: '0.75rem', borderRadius: 'var(--radius-md)' }}>
                  <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block' }}>Indexed Chunks</span>
                  <strong style={{ fontSize: '0.9rem', color: '#34d399' }}>{selectedDoc.chunkCount}</strong>
                </div>
                <div style={{ background: 'rgba(0,0,0,0.3)', padding: '0.75rem', borderRadius: 'var(--radius-md)' }}>
                  <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block' }}>File Size</span>
                  <strong style={{ fontSize: '0.9rem', color: '#a7f3d0' }}>{formatFileSize(selectedDoc.size)}</strong>
                </div>
                <div style={{ background: 'rgba(0,0,0,0.3)', padding: '0.75rem', borderRadius: 'var(--radius-md)' }}>
                  <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', display: 'block' }}>Embedding</span>
                  <strong style={{ fontSize: '0.75rem', color: '#c084fc' }}>{selectedDoc.embeddingModel || '—'}</strong>
                </div>
              </div>

              {/* Chunk list */}
              <div>
                <h4 style={{ fontSize: '0.85rem', fontWeight: '600', color: 'var(--text-muted)', marginBottom: '0.4rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <ListTree size={14} /> Vectorized Chunks {chunks ? `(${chunks.length})` : ''}
                </h4>
                {loadingChunks ? (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--text-muted)', fontSize: '0.8rem', padding: '1rem 0' }}>
                    <Loader2 size={16} style={{ animation: 'spin 1s linear infinite' }} /> Loading chunks...
                  </div>
                ) : chunks && chunks.length > 0 ? (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', maxHeight: '300px', overflowY: 'auto' }}>
                    {chunks.map((chunk) => (
                      <div key={chunk.id} style={{
                        background: 'rgba(10, 14, 23, 0.9)', padding: '0.6rem 0.75rem', borderRadius: 'var(--radius-sm)',
                        border: '1px solid rgba(255,255,255,0.08)'
                      }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.25rem', fontSize: '0.68rem', color: 'var(--text-dim)' }}>
                          <span>Chunk #{chunk.chunkIndex + 1}</span>
                          <span>~{chunk.tokenCount} tokens</span>
                        </div>
                        <p style={{ fontSize: '0.75rem', color: '#d1d5db', whiteSpace: 'pre-wrap', maxHeight: '110px', overflowY: 'auto', fontFamily: 'var(--font-body)' }}>
                          {chunk.text}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : chunks ? (
                  <p style={{ fontSize: '0.78rem', color: 'var(--text-dim)' }}>No chunks found.</p>
                ) : null}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
