import React, { useState, useRef } from 'react';
import { UploadCloud, FileText, CheckCircle2, AlertCircle, Loader2, Sparkles, Sliders, Type, RefreshCw } from 'lucide-react';
import { uploadFiles, uploadRawText } from '../../services/api';

export default function DocumentUploader({ apiKey, provider, embeddingModel, onUploadSuccess }) {
  const [mode, setMode] = useState('file'); // 'file' or 'text'
  const [dragActive, setDragActive] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState(null);

  // Paste Text State
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');

  // Chunking parameters
  const [showConfig, setShowConfig] = useState(false);
  const [chunkSize, setChunkSize] = useState(800);
  const [chunkOverlap, setChunkOverlap] = useState(150);

  const fileInputRef = useRef(null);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(Array.from(e.dataTransfer.files));
    }
  };

  const handleFileInputChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFiles(Array.from(e.target.files));
    }
  };

  const handleFiles = async (files) => {
    setIsUploading(true);
    setError(null);
    setSuccessMsg(null);

    try {
      const res = await uploadFiles(files, apiKey, provider, { chunkSize, chunkOverlap, embeddingModel });
      const replaced = res.documents && res.documents.some(d => d.replacedId);
      setSuccessMsg(
        `Successfully processed and indexed ${res.processedCount} document(s)!` +
        (replaced ? ' Re-uploads replaced older versions.' : '')
      );
      if (fileInputRef.current) fileInputRef.current.value = '';
      if (onUploadSuccess) onUploadSuccess();
    } catch (err) {
      setError(err.message || 'Failed to upload document');
    } finally {
      setIsUploading(false);
    }
  };

  const handleTextSubmit = async (e) => {
    e.preventDefault();
    if (!noteContent.trim()) {
      setError('Please enter text content to index.');
      return;
    }

    setIsUploading(true);
    setError(null);
    setSuccessMsg(null);

    try {
      const res = await uploadRawText(noteTitle || 'Pasted Note', noteContent, apiKey, provider, { chunkSize, chunkOverlap, embeddingModel });
      setSuccessMsg(
        'Text note processed and stored into vector database!' +
        (res.documents && res.documents.some(d => d.replacedId) ? ' Re-upload replaced older version.' : '')
      );
      setNoteTitle('');
      setNoteContent('');
      if (onUploadSuccess) onUploadSuccess();
    } catch (err) {
      setError(err.message || 'Failed to index text note');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="glass-panel" style={{ padding: '1.5rem', position: 'relative', overflow: 'hidden' }}>
      {/* Header & Mode Switch */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem', flexWrap: 'wrap', gap: '0.75rem' }}>
        <div>
          <h2 style={{ fontSize: '1.15rem', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <UploadCloud size={20} color="#818cf8" />
            Add Knowledge Documents
          </h2>
          <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            Upload PDFs, TXT, Markdown, CSV, DOCX, or paste custom text notes to feed your chatbot's brain.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <button
            onClick={() => setMode('file')}
            style={{
              padding: '0.35rem 0.75rem', borderRadius: 'var(--radius-sm)', fontSize: '0.8rem', fontWeight: '600',
              border: '1px solid var(--border-color)', cursor: 'pointer',
              background: mode === 'file' ? 'var(--primary)' : 'rgba(255,255,255,0.05)',
              color: mode === 'file' ? '#fff' : 'var(--text-muted)'
            }}
          >
            File Upload
          </button>
          <button
            onClick={() => setMode('text')}
            style={{
              padding: '0.35rem 0.75rem', borderRadius: 'var(--radius-sm)', fontSize: '0.8rem', fontWeight: '600',
              border: '1px solid var(--border-color)', cursor: 'pointer',
              background: mode === 'text' ? 'var(--primary)' : 'rgba(255,255,255,0.05)',
              color: mode === 'text' ? '#fff' : 'var(--text-muted)'
            }}
          >
            Paste Text Note
          </button>
          <button
            onClick={() => setShowConfig(!showConfig)}
            className="btn-secondary"
            style={{ padding: '0.35rem 0.6rem', fontSize: '0.8rem' }}
            title="Chunking Settings"
          >
            <Sliders size={14} />
          </button>
        </div>
      </div>

      {/* Advanced Chunking Config Drawer */}
      {showConfig && (
        <div className="animate-fade-in" style={{
          background: 'rgba(0, 0, 0, 0.3)',
          padding: '1rem',
          borderRadius: 'var(--radius-md)',
          marginBottom: '1rem',
          border: '1px dashed var(--border-color)',
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: '1rem'
        }}>
          <div>
            <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.3rem' }}>
              Chunk Size (Characters): <strong style={{ color: '#fff' }}>{chunkSize}</strong>
            </label>
            <input
              type="range"
              min="200"
              max="2000"
              step="50"
              value={chunkSize}
              onChange={(e) => setChunkSize(Number(e.target.value))}
              style={{ width: '100%', accentColor: 'var(--primary)' }}
            />
          </div>
          <div>
            <label style={{ fontSize: '0.78rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.3rem' }}>
              Chunk Overlap (Characters): <strong style={{ color: '#fff' }}>{chunkOverlap}</strong>
            </label>
            <input
              type="range"
              min="0"
              max="500"
              step="25"
              value={chunkOverlap}
              onChange={(e) => setChunkOverlap(Number(e.target.value))}
              style={{ width: '100%', accentColor: 'var(--primary)' }}
            />
          </div>
          <p style={{ gridColumn: '1 / -1', fontSize: '0.7rem', color: 'var(--text-dim)', marginTop: '-0.4rem' }}>
            Overlap is auto-clamped to 50% of chunk size. Embedding model: <strong style={{ color: '#34d399' }}>{embeddingModel || 'default'}</strong> · Provider: <strong style={{ color: '#22d3ee' }}>{provider || 'default'}</strong>
          </p>
        </div>
      )}

      {/* Mode 1: Drag & Drop File Zone */}
      {mode === 'file' ? (
        <div
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          style={{
            border: `2px dashed ${dragActive ? 'var(--primary)' : 'rgba(255, 255, 255, 0.15)'}`,
            borderRadius: 'var(--radius-lg)',
            padding: '2.5rem 1.5rem',
            textAlign: 'center',
            background: dragActive ? 'rgba(99, 102, 241, 0.1)' : 'rgba(0, 0, 0, 0.2)',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '0.75rem'
          }}
        >
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept=".pdf,.txt,.md,.json,.csv,.docx,.html,.htm"
            onChange={handleFileInputChange}
            style={{ display: 'none' }}
          />

          <div style={{
            width: '54px',
            height: '54px',
            borderRadius: '50%',
            background: 'rgba(99, 102, 241, 0.15)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            {isUploading ? (
              <Loader2 size={26} color="#818cf8" style={{ animation: 'spin 1s linear infinite' }} />
            ) : (
              <UploadCloud size={26} color="#818cf8" />
            )}
          </div>

          <div>
            <h3 style={{ fontSize: '1rem', fontWeight: '600', marginBottom: '0.25rem' }}>
              {isUploading ? 'Extracting Text & Generating Vectors...' : 'Click or Drag & Drop documents here'}
            </h3>
            <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
              Supports PDF, TXT, Markdown, JSON, CSV, DOCX, HTML (up to 25MB per file).
            </p>
          </div>

          <span className="badge badge-indigo">
            <Sparkles size={12} /> Heading-Aware Recursive Chunking
          </span>
        </div>
      ) : (
        /* Mode 2: Paste Raw Text Form */
        <form onSubmit={handleTextSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
          <div>
            <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.3rem' }}>
              Note Title / Topic
            </label>
            <input
              type="text"
              placeholder="e.g. Product FAQs 2026 or Company Policy"
              value={noteTitle}
              onChange={(e) => setNoteTitle(e.target.value)}
              style={{
                width: '100%', padding: '0.6rem 0.85rem', background: 'var(--bg-input)',
                border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)',
                color: '#fff', fontFamily: 'var(--font-body)', fontSize: '0.85rem', outline: 'none'
              }}
            />
          </div>

          <div>
            <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '0.3rem' }}>
              Raw Text / Article Content
            </label>
            <textarea
              rows={5}
              placeholder="Paste raw documentation, knowledge base articles, or text here..."
              value={noteContent}
              onChange={(e) => setNoteContent(e.target.value)}
              style={{
                width: '100%', padding: '0.75rem', background: 'var(--bg-input)',
                border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)',
                color: '#fff', fontFamily: 'var(--font-body)', fontSize: '0.85rem',
                outline: 'none', resize: 'vertical'
              }}
            />
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button type="submit" className="btn-primary" disabled={isUploading}>
              {isUploading ? (
                <><Loader2 size={16} style={{ animation: 'spin 1s linear infinite' }} /> Processing...</>
              ) : (
                <><Type size={16} /> Index Text Note</>
              )}
            </button>
          </div>
        </form>
      )}

      {/* Notifications */}
      {successMsg && (
        <div className="animate-fade-in" style={{
          marginTop: '1rem', padding: '0.75rem 1rem', borderRadius: 'var(--radius-md)',
          background: 'rgba(16, 185, 129, 0.15)', border: '1px solid rgba(16, 185, 129, 0.3)',
          color: '#34d399', fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: '0.5rem'
        }}>
          <CheckCircle2 size={18} /> {successMsg}
          <button
            onClick={() => setSuccessMsg(null)}
            style={{ marginLeft: 'auto', background: 'transparent', border: 'none', color: '#34d399', cursor: 'pointer', display: 'flex' }}
          >
            <RefreshCw size={13} />
          </button>
        </div>
      )}

      {error && (
        <div className="animate-fade-in" style={{
          marginTop: '1rem', padding: '0.75rem 1rem', borderRadius: 'var(--radius-md)',
          background: 'rgba(239, 68, 68, 0.15)', border: '1px solid rgba(239, 68, 68, 0.3)',
          color: '#f87171', fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: '0.5rem'
        }}>
          <AlertCircle size={18} /> {error}
          <button
            onClick={() => setError(null)}
            style={{ marginLeft: 'auto', background: 'transparent', border: 'none', color: '#f87171', cursor: 'pointer', display: 'flex' }}
          >
            <RefreshCw size={13} />
          </button>
        </div>
      )}
    </div>
  );
}
