import React, { useState } from 'react';
import { Plus, MessageSquare, Trash2, Pencil, Check, X, Sparkles } from 'lucide-react';

function timeAgo(iso) {
  if (!iso) return '';
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

export default function SessionSidebar({
  sessions,
  activeSessionId,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  onRenameSession
}) {
  const [editingId, setEditingId] = useState(null);
  const [editValue, setEditValue] = useState('');

  const startRename = (session) => {
    setEditingId(session.id);
    setEditValue(session.title);
  };

  const commitRename = (id) => {
    onRenameSession(id, editValue.trim());
    setEditingId(null);
  };

  return (
    <div className="session-sidebar" style={{
      width: '240px',
      minWidth: '240px',
      background: 'rgba(22, 27, 23, 0.9)',
      borderRight: '1px solid var(--border-color)',
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      overflow: 'hidden'
    }}>
      {/* New Chat Button */}
      <div style={{ padding: '0.9rem 0.85rem', borderBottom: '1px solid var(--border-color)' }}>
        <button
          onClick={onNewSession}
          className="btn-primary"
          style={{ width: '100%', justifyContent: 'center', fontSize: '0.85rem' }}
        >
          <Plus size={16} /> <span className="hide-on-mobile">New Chat</span>
        </button>
      </div>

      {/* Sessions List */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '0.5rem 0.6rem', display: 'flex', flexDirection: 'column', gap: '0.3rem' }}>
        <span className="hide-on-mobile" style={{ fontSize: '0.68rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', fontWeight: '700', padding: '0.3rem 0.4rem' }}>
          Conversations
        </span>

        {sessions.length === 0 && (
          <p style={{ fontSize: '0.78rem', color: 'var(--text-dim)', padding: '0.6rem 0.4rem' }}>
            No conversations yet.
          </p>
        )}

        {sessions.map(session => {
          const active = session.id === activeSessionId;
          const isEditing = editingId === session.id;
          return (
            <div
              key={session.id}
              onClick={() => { if (!isEditing) onSelectSession(session.id); }}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                padding: '0.55rem 0.6rem',
                borderRadius: 'var(--radius-md)',
                cursor: 'pointer',
                background: active ? 'rgba(136, 231, 20, 0.12)' : 'transparent',
                border: `1px solid ${active ? 'rgba(136, 231, 20, 0.35)' : 'transparent'}`,
                transition: 'all 0.15s ease'
              }}
              onMouseEnter={(e) => { if (!active) e.currentTarget.style.background = 'rgba(255,255,255,0.04)'; }}
              onMouseLeave={(e) => { if (!active) e.currentTarget.style.background = 'transparent'; }}
            >
              <MessageSquare size={14} color={active ? 'var(--lime-primary)' : 'var(--text-dim)'} style={{ flexShrink: 0 }} />
              {isEditing ? (
                <input
                  autoFocus
                  value={editValue}
                  onChange={(e) => setEditValue(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') commitRename(session.id);
                    if (e.key === 'Escape') setEditingId(null);
                  }}
                  onClick={(e) => e.stopPropagation()}
                  style={{
                    flex: 1, background: 'var(--bg-input)', border: '1px solid var(--lime-primary)',
                    borderRadius: '6px', color: '#fff', fontSize: '0.78rem', padding: '0.2rem 0.4rem', outline: 'none'
                  }}
                />
              ) : (
                <span style={{
                  flex: 1, fontSize: '0.8rem', fontWeight: active ? '700' : '500', color: active ? '#fff' : 'var(--text-muted)',
                  overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'
                }}>
                  {session.title}
                </span>
              )}
              <span style={{ fontSize: '0.62rem', color: 'var(--text-dim)', flexShrink: 0 }}>{timeAgo(session.updatedAt)}</span>

              {!isEditing && (
                <div style={{ display: 'flex', gap: '0.15rem', flexShrink: 0 }}>
                  <button
                    onClick={(e) => { e.stopPropagation(); startRename(session); }}
                    className="icon-btn"
                    title="Rename"
                    style={{ padding: '0.2rem', borderRadius: '6px', background: 'transparent', border: 'none', color: 'var(--text-dim)', cursor: 'pointer' }}
                  >
                    <Pencil size={11} />
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); if (window.confirm(`Delete "${session.title}"?`)) onDeleteSession(session.id); }}
                    className="icon-btn"
                    title="Delete"
                    style={{ padding: '0.2rem', borderRadius: '6px', background: 'transparent', border: 'none', color: 'var(--text-dim)', cursor: 'pointer' }}
                  >
                    <Trash2 size={11} />
                  </button>
                </div>
              )}
              {isEditing && (
                <div style={{ display: 'flex', gap: '0.15rem', flexShrink: 0 }}>
                  <button onClick={(e) => { e.stopPropagation(); commitRename(session.id); }} style={{ background: 'transparent', border: 'none', color: 'var(--lime-primary)', cursor: 'pointer' }}>
                    <Check size={12} />
                  </button>
                  <button onClick={(e) => { e.stopPropagation(); setEditingId(null); }} style={{ background: 'transparent', border: 'none', color: 'var(--accent-coral)', cursor: 'pointer' }}>
                    <X size={12} />
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div style={{
        padding: '0.75rem 0.85rem', borderTop: '1px solid var(--border-color)',
        display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.7rem', color: 'var(--text-dim)'
      }}>
        <Sparkles size={12} color="var(--lime-primary)" />
        <span className="hide-on-mobile">PAVIT AI · sessions saved locally</span>
      </div>
    </div>
  );
}
