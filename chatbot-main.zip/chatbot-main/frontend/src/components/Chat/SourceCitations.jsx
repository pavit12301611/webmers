import React, { useState } from 'react';
import { BookOpen, FileText, ChevronDown, ChevronUp, Info } from 'lucide-react';

export default function SourceCitations({ citations, retrievalMeta }) {
  const [expanded, setExpanded] = useState(false);

  if (!citations || citations.length === 0) return null;

  return (
    <div style={{
      marginTop: '0.85rem',
      padding: '0.65rem 0.85rem',
      borderRadius: 'var(--radius-md)',
      background: 'rgba(0, 0, 0, 0.3)',
      border: '1px solid rgba(99, 102, 241, 0.2)',
      fontSize: '0.8rem'
    }}>
      {/* Header bar */}
      <div
        onClick={() => setExpanded(!expanded)}
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          cursor: 'pointer',
          userSelect: 'none'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', color: '#818cf8', fontWeight: '600' }}>
          <BookOpen size={15} />
          <span>Retrieved Context Sources ({citations.length})</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', color: 'var(--text-muted)' }}>
          <span style={{ fontSize: '0.72rem' }}>{expanded ? 'Hide Details' : 'View Sources'}</span>
          {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
        </div>
      </div>

      {/* Retrieval metadata line */}
      {retrievalMeta && !expanded && (
        <div style={{ marginTop: '0.35rem', fontSize: '0.68rem', color: 'var(--text-dim)', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
          <Info size={11} />
          <span>
            {retrievalMeta.provider} · {retrievalMeta.chatModel}
            {retrievalMeta.embeddingFallback ? ' · local fallback embeddings' : ''}
            {retrievalMeta.skippedDimensionMismatch > 0 ? ` · ${retrievalMeta.skippedDimensionMismatch} chunk(s) skipped (dim mismatch)` : ''}
          </span>
        </div>
      )}

      {/* Expanded Citations List */}
      {expanded && (
        <div className="animate-fade-in" style={{
          marginTop: '0.75rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.6rem',
          borderTop: '1px dashed rgba(255,255,255,0.08)',
          paddingTop: '0.6rem'
        }}>
          {citations.map((cite) => (
            <div
              key={cite.citationId}
              style={{
                background: 'rgba(11, 15, 25, 0.6)',
                padding: '0.6rem 0.75rem',
                borderRadius: 'var(--radius-sm)',
                border: '1px solid var(--border-color)'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.3rem', flexWrap: 'wrap', gap: '0.3rem' }}>
                <span style={{ fontWeight: '600', color: '#34d399', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                  <FileText size={13} color="#06b6d4" /> Source [{cite.citationId}]: {cite.docName}
                </span>
                <span className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>
                  Score: {(cite.similarityScore * 100).toFixed(1)}%
                </span>
              </div>
              {typeof cite.semanticScore === 'number' && typeof cite.lexicalScore === 'number' && (
                <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.35rem', fontSize: '0.66rem', color: 'var(--text-dim)' }}>
                  <span>semantic {(cite.semanticScore * 100).toFixed(0)}%</span>
                  <span>·</span>
                  <span>keyword {(cite.lexicalScore * 100).toFixed(0)}%</span>
                </div>
              )}
              <p style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '0.75rem',
                color: '#d1d5db',
                background: 'rgba(0,0,0,0.4)',
                padding: '0.5rem',
                borderRadius: '4px',
                whiteSpace: 'pre-wrap',
                maxHeight: '120px',
                overflowY: 'auto'
              }}>
                {cite.snippet}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
