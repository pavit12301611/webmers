import React, { useState, useRef, useEffect } from 'react';
import { Trash2, Loader2, CornerDownLeft, Square, FileText, MessageSquare } from 'lucide-react';

export default function ChatInput({ onSendMessage, isGenerating, onStop, onClearChat, hasMessages, mode, setMode }) {
  const [input, setInput] = useState('');
  const textareaRef = useRef(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 160)}px`;
    }
  }, [input]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!input.trim() || isGenerating) return;
    onSendMessage(input);
    setInput('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{
      position: 'relative',
      background: 'var(--bg-card)',
      border: `1px solid ${mode === 'sop' ? 'rgba(6, 182, 212, 0.4)' : 'var(--border-color)'}`,
      borderRadius: 'var(--radius-xl)',
      padding: '0.65rem 0.9rem',
      display: 'flex',
      alignItems: 'flex-end',
      gap: '0.6rem',
      boxShadow: '0 10px 40px rgba(0, 0, 0, 0.5), 0 0 20px rgba(136, 231, 20, 0.08)',
      backdropFilter: 'blur(20px)',
      transition: 'all 0.2s ease'
    }}>
      {hasMessages && (
        <button
          type="button"
          onClick={onClearChat}
          className="btn-secondary"
          style={{ padding: '0.55rem', borderRadius: '50%', color: 'var(--text-muted)', flexShrink: 0 }}
          title="Clear Conversation"
        >
          <Trash2 size={16} />
        </button>
      )}

      {/* Mode toggle: Chat / SOP */}
      <button
        type="button"
        onClick={() => setMode(mode === 'sop' ? 'chat' : 'sop')}
        title={mode === 'sop' ? 'Switch to normal chat' : 'Generate a structured SOP from documents'}
        style={{
          display: 'flex', alignItems: 'center', gap: '0.35rem', flexShrink: 0,
          padding: '0.45rem 0.7rem', borderRadius: '999px', cursor: 'pointer',
          border: `1px solid ${mode === 'sop' ? 'rgba(6, 182, 212, 0.6)' : 'var(--border-color)'}`,
          background: mode === 'sop' ? 'rgba(6, 182, 212, 0.15)' : 'rgba(255,255,255,0.04)',
          color: mode === 'sop' ? '#22d3ee' : 'var(--text-muted)',
          fontSize: '0.75rem', fontWeight: '700', transition: 'all 0.2s ease'
        }}
      >
        {mode === 'sop' ? <MessageSquare size={13} /> : <FileText size={13} />}
        {mode === 'sop' ? 'Chat' : 'SOP'}
      </button>

      <textarea
        ref={textareaRef}
        rows={1}
        placeholder={mode === 'sop' ? 'Describe the procedure topic to turn into an SOP...' : 'Type to start chatting...'}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={handleKeyDown}
        disabled={isGenerating}
        style={{
          flex: 1,
          background: 'transparent',
          border: 'none',
          outline: 'none',
          color: '#ffffff',
          fontFamily: 'var(--font-body)',
          fontSize: '0.92rem',
          resize: 'none',
          maxHeight: '160px',
          padding: '0.4rem 0.25rem',
          lineHeight: '1.4'
        }}
      />

      {isGenerating ? (
        <button
          type="button"
          onClick={onStop}
          className="btn-danger"
          title="Stop generating"
          style={{
            borderRadius: '50%', width: '44px', height: '44px', padding: 0, flexShrink: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center'
          }}
        >
          <Square size={15} fill="currentColor" />
        </button>
      ) : (
        <button
          type="submit"
          className="btn-primary"
          disabled={!input.trim()}
          title={mode === 'sop' ? 'Generate SOP' : 'Send message'}
          style={{
            borderRadius: '50%', width: '44px', height: '44px', padding: 0, flexShrink: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            opacity: !input.trim() ? 0.4 : 1,
            cursor: !input.trim() ? 'not-allowed' : 'pointer'
          }}
        >
          <CornerDownLeft size={18} color="var(--lime-text-dark)" />
        </button>
      )}

      {isGenerating && (
        <span style={{ position: 'absolute', top: '-2.1rem', right: '0.6rem', fontSize: '0.72rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
          <Loader2 size={12} style={{ animation: 'spin 1s linear infinite' }} /> Generating {mode === 'sop' ? 'SOP' : 'answer'}…
        </span>
      )}
    </form>
  );
}
