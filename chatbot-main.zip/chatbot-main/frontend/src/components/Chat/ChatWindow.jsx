import React, { useRef, useEffect } from 'react';
import { Zap, BookOpen, UploadCloud, FileText } from 'lucide-react';
import MessageItem from './MessageItem';
import ChatInput from './ChatInput';
import SessionSidebar from './SessionSidebar';

export default function ChatWindow({
  sessions,
  activeSessionId,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  onRenameSession,
  messages,
  isGenerating,
  onSendMessage,
  onStop,
  onRegenerate,
  onClearChat,
  stats,
  mode,
  setMode,
  onSwitchToDashboard
}) {
  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isGenerating]);

  const samplePrompts = [
    "Summarize the main topics discussed in the uploaded documents.",
    "What are the key requirements or policies mentioned?",
    "Extract any important dates, numbers, or action items.",
    "Compare key points between the knowledge base files."
  ];

  const hasMessages = messages.length > 0;

  return (
    <div style={{
      display: 'flex',
      height: 'calc(100vh - 85px)',
      maxWidth: '1400px',
      margin: '0 auto',
      padding: '0.75rem'
    }}>
      {/* Sessions Sidebar */}
      <SessionSidebar
        sessions={sessions}
        activeSessionId={activeSessionId}
        onSelectSession={onSelectSession}
        onNewSession={onNewSession}
        onDeleteSession={onDeleteSession}
        onRenameSession={onRenameSession}
      />

      {/* Chat Column */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', paddingLeft: '0.75rem', minWidth: 0 }}>
        {/* Mode banner */}
        {mode === 'sop' && (
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            background: 'rgba(6, 182, 212, 0.1)', border: '1px solid rgba(6, 182, 212, 0.3)',
            borderRadius: 'var(--radius-md)', padding: '0.5rem 0.9rem', marginBottom: '0.6rem', fontSize: '0.8rem'
          }}>
            <span style={{ color: '#22d3ee', fontWeight: '600' }}>
              📋 SOP Generator mode — PAVIT will write a structured procedure from your documents.
            </span>
            <button
              onClick={() => setMode('chat')}
              className="btn-secondary"
              style={{ padding: '0.25rem 0.7rem', fontSize: '0.72rem' }}
            >
              Exit SOP Mode
            </button>
          </div>
        )}

        {/* Messages Scroll Area */}
        <div style={{
          flex: 1,
          overflowY: 'auto',
          paddingRight: '0.5rem',
          marginBottom: '0.75rem'
        }}>
          {!hasMessages ? (
            /* Empty Chat State */
            <div className="animate-fade-in" style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              height: '100%',
              textAlign: 'center',
              padding: '2rem'
            }}>
              <div style={{
                width: '68px',
                height: '68px',
                borderRadius: '50%',
                background: 'var(--lime-primary)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '1.25rem',
                boxShadow: '0 0 30px var(--lime-glow)'
              }}>
                <Zap size={36} color="var(--lime-text-dark)" />
              </div>

              <h2 style={{ fontSize: '1.65rem', fontWeight: '800', marginBottom: '0.4rem', color: '#ffffff' }}>
                PAVIT <span style={{ color: 'var(--lime-primary)' }}>AI</span>
              </h2>
              <p style={{ fontSize: '0.92rem', color: 'var(--text-muted)', maxWidth: '540px', marginBottom: '1.5rem' }}>
                Ask questions about your uploaded PDFs, notes, or knowledge base. Answers are grounded in your documents using RAG vector search with source citations.
                <span style={{ display: 'block', marginTop: '0.35rem', fontSize: '0.78rem', color: 'var(--text-dim)' }}>Built by PAVIT</span>
              </p>

              {stats?.totalDocuments === 0 ? (
                <div className="glass-panel" style={{ padding: '1.5rem 2rem', textAlign: 'center' }}>
                  <p style={{ fontSize: '0.88rem', color: '#fbbf24', marginBottom: '0.85rem' }}>
                    ⚠️ No documents found in your knowledge base yet.
                  </p>
                  <button onClick={onSwitchToDashboard} className="btn-primary">
                    <UploadCloud size={16} /> Upload Documents in Dashboard
                  </button>
                </div>
              ) : (
                <div style={{ width: '100%', maxWidth: '640px' }}>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: '700', display: 'block', marginBottom: '0.75rem' }}>
                    Suggested Questions
                  </span>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                    {samplePrompts.map((prompt, idx) => (
                      <button
                        key={idx}
                        onClick={() => onSendMessage(prompt)}
                        className="glass-panel"
                        style={{
                          padding: '0.85rem 1rem',
                          textAlign: 'left',
                          cursor: 'pointer',
                          fontSize: '0.84rem',
                          color: 'var(--text-main)',
                          display: 'flex',
                          alignItems: 'flex-start',
                          gap: '0.5rem',
                          border: 'none'
                        }}
                      >
                        <BookOpen size={16} color="var(--lime-primary)" style={{ marginTop: '2px', flexShrink: 0 }} />
                        <span>{prompt}</span>
                      </button>
                    ))}
                  </div>
                  <button
                    onClick={() => setMode(mode === 'sop' ? 'chat' : 'sop')}
                    className="glass-panel"
                    style={{
                      marginTop: '0.9rem', width: '100%', padding: '0.8rem 1rem', cursor: 'pointer',
                      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
                      fontSize: '0.84rem', color: '#22d3ee', border: '1px dashed rgba(6, 182, 212, 0.4)'
                    }}
                  >
                    <FileText size={16} /> {mode === 'sop' ? 'Switch to normal Q&A chat' : 'Or generate a structured SOP from your documents'}
                  </button>
                </div>
              )}
            </div>
          ) : (
            /* Active Chat Messages */
            <>
              {messages.map((msg, idx) => (
                <MessageItem
                  key={`${msg.role}-${idx}-${msg.ts || idx}`}
                  message={msg}
                  isLast={idx === messages.length - 1}
                  onRegenerate={!isGenerating && idx === messages.length - 1 && msg.role === 'assistant' && !msg.generating ? onRegenerate : null}
                />
              ))}
              <div ref={messagesEndRef} />
            </>
          )}
        </div>

        {/* Input Form Footer */}
        <ChatInput
          onSendMessage={onSendMessage}
          isGenerating={isGenerating}
          onStop={onStop}
          onClearChat={onClearChat}
          hasMessages={hasMessages}
          mode={mode}
          setMode={setMode}
        />
      </div>
    </div>
  );
}
