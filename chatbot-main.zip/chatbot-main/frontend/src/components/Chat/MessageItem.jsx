import React, { useState } from 'react';
import { User, Zap, Copy, Check, RefreshCw, Loader2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import SourceCitations from './SourceCitations';

function CodeBlock({ language, children }) {
  const [copied, setCopied] = useState(false);
  const code = String(children || '').replace(/\n$/, '');
  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div style={{ position: 'relative' }}>
      <button
        onClick={handleCopy}
        title="Copy code"
        style={{
          position: 'absolute', top: '0.45rem', right: '0.55rem', zIndex: 2,
          background: 'rgba(0,0,0,0.5)', border: '1px solid var(--border-color)', borderRadius: '6px',
          color: 'var(--text-muted)', padding: '0.2rem 0.45rem', cursor: 'pointer', fontSize: '0.7rem',
          display: 'flex', alignItems: 'center', gap: '0.25rem'
        }}
      >
        {copied ? <Check size={11} color="#34d399" /> : <Copy size={11} />}
        {copied ? 'Copied' : language || 'code'}
      </button>
      <pre><code>{children}</code></pre>
    </div>
  );
}

export default function MessageItem({ message, isLast, onRegenerate }) {
  const [copied, setCopied] = useState(false);
  const isUser = message.role === 'user';
  const isGenerating = message.generating === true;

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div style={{
      display: 'flex',
      flexDirection: isUser ? 'row-reverse' : 'row',
      gap: '0.85rem',
      alignItems: 'flex-start',
      marginBottom: '1.25rem'
    }}>
      {/* Avatar Icon */}
      <div style={{
        width: '38px',
        height: '38px',
        borderRadius: '50%',
        background: isUser ? 'var(--lime-primary)' : 'rgba(255, 255, 255, 0.08)',
        border: isUser ? 'none' : '1px solid var(--border-color)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0,
        boxShadow: isUser ? '0 0 14px var(--lime-glow)' : 'none'
      }}>
        {isUser ? (
          <User size={18} color="var(--lime-text-dark)" />
        ) : (
          <Zap size={18} color="var(--lime-primary)" />
        )}
      </div>

      {/* Message Bubble Container */}
      <div style={{
        maxWidth: '82%',
        background: isUser ? 'var(--lime-primary)' : 'var(--bg-card)',
        color: isUser ? 'var(--lime-text-dark)' : 'var(--text-main)',
        padding: '1rem 1.25rem',
        borderRadius: isUser ? '22px 22px 4px 22px' : '22px 22px 22px 4px',
        border: isUser ? 'none' : '1px solid var(--border-color)',
        boxShadow: isUser
          ? '0 6px 20px var(--lime-glow)'
          : '0 8px 30px rgba(0, 0, 0, 0.4)',
        position: 'relative',
        minWidth: '180px'
      }}>
        {/* Header inside Bubble */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '0.4rem',
          fontSize: '0.78rem',
          fontWeight: '700',
          opacity: 0.85
        }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            {isUser ? 'You' : 'PAVIT AI'}
            {isGenerating && <Loader2 size={12} style={{ animation: 'spin 1s linear infinite' }} />}
          </span>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.2rem' }}>
            {onRegenerate && (
              <button
                onClick={onRegenerate}
                style={{
                  background: 'transparent', border: 'none', cursor: 'pointer',
                  color: isUser ? 'var(--lime-text-dark)' : 'var(--text-muted)',
                  display: 'flex', alignItems: 'center', padding: '0.1rem 0.3rem'
                }}
                title="Regenerate answer"
              >
                <RefreshCw size={13} />
              </button>
            )}
            <button
              onClick={handleCopy}
              style={{
                background: 'transparent', border: 'none', cursor: 'pointer',
                color: isUser ? 'var(--lime-text-dark)' : 'var(--text-muted)',
                display: 'flex', alignItems: 'center', padding: '0.1rem 0.3rem'
              }}
              title="Copy message"
            >
              {copied ? <Check size={13} color={isUser ? '#000' : '#88e714'} /> : <Copy size={13} />}
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="markdown-content" style={{
          fontSize: '0.92rem',
          lineHeight: '1.55',
          fontWeight: isUser ? '500' : '400'
        }}>
          {isUser ? (
            <span style={{ whiteSpace: 'pre-wrap' }}>{message.content}</span>
          ) : (
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              components={{
                code({ node, className, children, ...props }) {
                  const match = /language-(\w+)/.exec(className || '');
                  const isBlock = node?.position?.start?.line !== node?.position?.end?.line || className;
                  if (isBlock && className) {
                    return <CodeBlock language={match ? match[1] : 'code'}>{children}</CodeBlock>;
                  }
                  return <code className={className} {...props}>{children}</code>;
                },
                a({ children, ...props }) {
                  return <a {...props} target="_blank" rel="noreferrer">{children}</a>;
                }
              }}
            >
              {message.content || ''}
            </ReactMarkdown>
          )}
        </div>

        {/* Source Citations for Assistant */}
        {!isUser && message.citations && message.citations.length > 0 && (
          <SourceCitations citations={message.citations} retrievalMeta={message.retrievalMeta} />
        )}
      </div>
    </div>
  );
}
