const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const config = require('./src/config');

const uploadRoutes = require('./src/routes/upload');
const documentRoutes = require('./src/routes/documents');
const chatRoutes = require('./src/routes/chat');
const statsRoutes = require('./src/routes/stats');
const settingsRoutes = require('./src/routes/settings');
const sopRoutes = require('./src/routes/sop');

const app = express();

/* ---------------- Security & Utility Middleware ---------------- */

// Simple in-memory sliding-window rate limiter (per IP)
const requestCounts = new Map();
function rateLimit(req, res, next) {
  const now = Date.now();
  const key = req.ip || 'unknown';
  const bucket = (requestCounts.get(key) || []).filter(t => now - t < config.rateLimitWindowMs);
  if (bucket.length >= config.rateLimitMax) {
    const retryAfter = Math.ceil(config.rateLimitWindowMs / 1000);
    res.setHeader('Retry-After', retryAfter);
    return res.status(429).json({ success: false, error: `Too many requests. Try again in ${retryAfter}s.` });
  }
  bucket.push(now);
  requestCounts.set(key, bucket);
  next();
}

// Basic security headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Powered-By', config.appName);
  next();
});

app.use(cors({ origin: config.corsOrigin === '*' ? true : config.corsOrigin, credentials: true }));
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Protect mutation/LLM endpoints with the rate limiter
app.use('/api/chat', rateLimit);
app.use('/api/sop', rateLimit);
app.use('/api/upload', rateLimit);

/* ---------------- API Routes ---------------- */

app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    appName: config.appName,
    builtBy: config.builtBy,
    version: config.version,
    provider: config.llmProvider,
    uptimeSeconds: Math.round(process.uptime()),
    timestamp: new Date().toISOString()
  });
});

app.use('/api/upload', uploadRoutes);
app.use('/api/documents', documentRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/stats', statsRoutes);
app.use('/api/settings', settingsRoutes);
app.use('/api/sop', sopRoutes);

// 404 for unknown API routes (must be registered before SPA fallback)
app.use('/api', (req, res) => {
  res.status(404).json({ success: false, error: `API route not found: ${req.method} ${req.originalUrl}` });
});

/* ---------------- Frontend Static Serving (SPA) ---------------- */

const distPath = path.join(__dirname, 'frontend/dist');
if (fs.existsSync(distPath)) {
  console.log(`[${config.appName}] Serving built React frontend from: ${distPath}`);
  app.use(express.static(distPath));

  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    res.sendFile(path.join(distPath, 'index.html'));
  });
} else {
  console.log(`[${config.appName}] No frontend dist build found. Run "npm run build" to build and serve the UI.`);
}

/* ---------------- Error Handling ---------------- */

app.use((err, req, res, next) => {
  console.error('[Server Error]:', err.message);
  if (res.headersSent) return next(err);
  res.status(500).json({ success: false, error: err.message || 'Internal Server Error' });
});

/* ---------------- Boot ---------------- */

const startServer = () => {
  const server = app.listen(config.port, () => {
    console.log(`\n====================================================`);
    console.log(`🚀 ${config.appName} Server running at: http://localhost:${config.port}`);
    console.log(`👤 Built by ${config.builtBy}`);
    console.log(`📁 Persistent Vector Store: ${config.dataDir}`);
    console.log(`🔑 Active Provider: ${config.llmProvider.toUpperCase()}`);
    console.log(`🧠 Chat Model: ${config.chatModelFor(config.llmProvider)} | Embedding: ${config.embeddingModelFor(config.llmProvider)}`);
    console.log(`====================================================\n`);
  });

  server.requestTimeout = 0; // allow long-lived SSE streams
  server.keepAliveTimeout = 60000;
  return server;
};

// Export for tests, start when run directly
if (require.main === module) {
  startServer();
} else {
  module.exports = { app, startServer };
}
